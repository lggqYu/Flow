﻿#ifndef ZTABWIDGET_H
#define ZTABWIDGET_H

#include <QTabWidget>
#include <QMouseEvent>
#include <QGridLayout>
#include <QMenu>
#include <QTabBar>
#include <QDebug>
#include "ZWidget.h"
#include "ZTabBar.h"

//----------------------------------------------------------------------------
// brief:  QTabWidget增强版，支持关闭Tab页
// update: 增加右键菜单 - Z @ 2022年4月15日18:35:03
// update: 增加Dock功能 - Z @ 2022年4月20日17:20:25
//----------------------------------------------------------------------------
class ZTabWidget : public QTabWidget
{
    Q_OBJECT

public:
    ZTabWidget(QWidget * parent = 0);
    ~ZTabWidget();

    void initMenu();
    void setTabsClosable(bool closeable);
    void setTabDraggable(bool draggable);

public slots:
    void removeSubTab(QString uuid);
    void clearTab();  //清除tab
private slots:
    void removeSubTab(int index);
    void slotTabDock(QCloseEvent * event);     // 停靠Tab页
    void slotTabDrag(int index, QPoint point); // 拖出Tab页
    void showMenu(const QPoint &pos);
    bool isDirty()        { return m_dirty; }
    void setDirty(bool d) { m_dirty = d;    }

public:
    QMap<QString, QWidget *> tabMap;           // 创建当前字符与相关界面的哈希映射
    ZTabBar *                tabBar;
    QMap<QString, ZWidget*>  zWMap;  //外部的单独子窗口
private:
    QMenu *                  m_menu;
    bool                     m_dirty = false;  // 已修改

};

/*************************************************************
 * 常用初始化设置
 *************************************************************

// 初始化设置tabWidget
ui->tabWidget->setTabPosition(QTabWidget::North);
// ui->tabWidget->setTabShape(QTabWidget::Triangular);
ui->tabWidget->setMovable(true);
ui->tabWidget->setTabsClosable(true);
ui->tabWidget->setUsesScrollButtons(true);

 ************************************************************/

#endif // ZTABWIDGET_H
