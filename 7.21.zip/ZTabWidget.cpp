﻿#include "ZTabWidget.h"

ZTabWidget::ZTabWidget(QWidget * parent):
    QTabWidget(parent) {
    // 这里是关键，这样用我们自定义的ZTabBar替换原来的QTabBar
    tabBar = new ZTabBar;
    setTabBar(tabBar);

    initMenu();

    connect (this, SIGNAL(currentChanged(int)), this, SLOT(setCurrentIndex(int)));
}

ZTabWidget::~ZTabWidget() {
    //删除所有外面的面板
    QList<QString> keys = zWMap.keys();
    for (int i = 0; i < keys.length(); ++i) {
        ZWidget* w = zWMap.value(keys[i]);
        zWMap.remove(keys[i]);
        delete w;
    }
}

void ZTabWidget::initMenu() {
    // 右键菜单初始化
    setContextMenuPolicy(Qt::CustomContextMenu);
    m_menu = new QMenu(this);
    QAction * action = new QAction("关闭当前页面", this);
    connect (action, &QAction::triggered, this, [this]() {
        removeSubTab(currentIndex());
    });
    m_menu->addAction(action);
    action = new QAction("关闭其他页面", this);
    connect (action, &QAction::triggered, this, [this]() {
        for (int i = count() - 1; i >= 0; i--) {
            if (i != currentIndex()) {
                removeSubTab(i);
            }
        }
    });
    m_menu->addAction(action);
    action = new QAction("关闭左侧所有页面", this);
    connect (action, &QAction::triggered, this, [this]() {
        for (int i = currentIndex() - 1; i >= 0; i--) {
            removeSubTab(i);
        }
    });
    m_menu->addAction(action);
    action = new QAction("关闭右侧所有页面", this);
    connect (action, &QAction::triggered, this, [this]() {
        for (int i = count() - 1; i > currentIndex(); i--) {
            removeSubTab(i);
        }
    });
    m_menu->addAction(action);
    action = new QAction("关闭所有未修改页面", this);
    connect (action, &QAction::triggered, this, [this]() {
        for (int i = count() - 1; i >= 0; i--) {
            if (!tabText(i).endsWith("*")) {
                removeSubTab(i);
            }
        }
    });
    m_menu->addAction(action);
}

void ZTabWidget::setTabsClosable(bool closeable) {
    // 允许关闭则启动右键菜单
    if (closeable) {
        connect (this, &QTabWidget::customContextMenuRequested, this, &ZTabWidget::showMenu);
        connect (this, SIGNAL(tabCloseRequested(int)), this, SLOT(removeSubTab(int)));
    }
    else {
        disconnect (this, &QTabWidget::customContextMenuRequested, this, &ZTabWidget::showMenu);
        disconnect (this, SIGNAL(tabCloseRequested(int)), this, SLOT(removeSubTab(int)));
    }
    QTabWidget::setTabsClosable(closeable);
}

void ZTabWidget::setTabDraggable(bool draggable) {
    // Tab页拖拽使能
    if (draggable) {
        connect (tabBar, SIGNAL(sigTabDrag(int, QPoint)), this, SLOT(slotTabDrag(int, QPoint)));
    }
    else {
        disconnect (tabBar, SIGNAL(sigTabDrag(int, QPoint)), this, SLOT(slotTabDrag(int, QPoint)));
    }
}

void ZTabWidget::clearTab(){
    for (int i = count() - 1; i >= 0; i--) {
        removeSubTab(i);
    }
    QList<QString> keys = zWMap.keys();
    for (int i = 0; i < keys.length(); ++i) {
        ZWidget* w = zWMap.value(keys[i]);
        zWMap.remove(keys[i]);
        delete w;
    }
}
void ZTabWidget::removeSubTab(QString uuid) {
    QWidget * tab = tabMap.value(uuid);
    tabMap.remove(uuid);

    removeTab(indexOf(tab));
    //从zwmap删除
    ZWidget* w = zWMap.value(uuid);
    zWMap.remove(uuid);
    delete tab;
    delete w;
}

void ZTabWidget::removeSubTab(int index) {
    QWidget * tab = widget(index);
    QString uuid = tabMap.key(tab);
    tabMap.remove(widget(index)->whatsThis());
    removeTab(index);
    delete tab;
    ZWidget* w = zWMap.value(uuid);
    zWMap.remove(uuid);
    delete w;
}

void ZTabWidget::slotTabDrag(int index, QPoint point) {
    ZWidget * wid = new ZWidget;
    QWidget * tab = widget(index);
    QString id = tabMap.key(tab);
    QString windowName = tabText(index);
    removeTab(index); // 从TabWidget移除，添加到弹出Widget
    connect (wid, SIGNAL(sigCloseEvent(QCloseEvent *)), this, SLOT(slotTabDock(QCloseEvent *)), Qt::QueuedConnection);

    QGridLayout * layout = new QGridLayout;
    layout->addWidget(tab);
    wid->setLayout(layout);
    wid->resize(800, 600);
    wid->move(point + pos() + pos());
    wid->setWindowTitle(windowName);
    wid->show();
    tab->show();
    zWMap.insert(id, wid);
}

void ZTabWidget::slotTabDock(QCloseEvent * event) {
    ZWidget * wid = qobject_cast<ZWidget *>(sender());
    QObjectList list = wid->children();
    QWidget * edit = NULL;

    for (int i = 0; i < list.count(); ++i) {
        if (list[i]->inherits("QWidget")) {
            edit = qobject_cast<QWidget *>(list[i]);
            break;
        }
    }
    if (edit == NULL) {
        return;
    }

    edit->setParent(this);
    addTab(edit, wid->windowTitle()); // 添加回TabWidget
    event->accept();
    QString id = tabMap.key(edit);
    // wid关闭
    tabMap.remove(id);
    zWMap.remove(id);
    delete wid;
}

void ZTabWidget::showMenu(const QPoint &pos) {
    if (tabBar->rect().contains(pos)) {
        setCurrentIndex(tabBar->tabAt(pos));
        m_menu->exec(QCursor::pos());
    }
}
