#ifndef PLOT_H
#define PLOT_H

#include <FlowLayout.h>
#include <QWidget>
#include <appData.h>
#include "quiwidget.h"
#include "ZCurvetop.h"
#include "qcustomplot.h"
#include "ZCurveProperty.h"
#include <QChartView>
#include <QMap>
#include "ProjectManager/ProjectManager.h"
#include "../DataPool/MainDataPool.h"

namespace Ui {
class Plot;
}

class Plot : public QWidget
{
    Q_OBJECT

public:
    explicit Plot(QWidget *parent = nullptr);
    ~Plot();

    void initCurve();

    void initform();
protected:
    void dragEnterEvent(QDragEnterEvent   *event) override;
    void dragMoveEvent(QDragMoveEvent   *event) override;
    void dropEvent(QDropEvent   *event) override;

signals:
    void varselect(int a, QString uid);
    void signalUpdateGraph(QCPGraph * m_Graph,int a);
    void sigShow(bool show);

public slots:
    void exportRecordChart();
    void setcurveproperty();

    void addVar(CurveVarInfo varInfo,int col);
    void hideShowvar(bool check);
    void deleteVar();

    void mousePressEvent(QMouseEvent* e) ;

    // listwidget可见不可见按钮
    void pushButton_show_clicked();
    void pushButton_hide_clicked();
    void updateCurveInfos(CurveInfo m_curveinfo);
    void pushButton_editor_clicked();
    void setCurName(QString name);
private:
    Ui::Plot *ui;

    FlowLayout * flowLayout;
    CurveInfo cinfo;
    ProjectManager *projectmanager;
    MainDataPool *m_maindatapool = nullptr;
    QString m_name;

    // 创建的初始颜色
    QList<QColor> allcolor;

    QMap<ZCurvetop*, CurveVarInfo> curvedata;//所有变量的数据
    QCPItemTracer*                           tracer;
    QMap<QString, QCPItemText*>              flagContainer;            // 数据标签容器
    QMap<QCPGraph*, QMap<int, QCPItemText*>> flag2Graph;               // 数据标签容器
};


#endif // PLOT_H
