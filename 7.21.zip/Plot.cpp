﻿#include "Plot.h"
#include "ui_Plot.h"

Plot::Plot(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Plot)
{
    ui->setupUi(this);

    flowLayout = new FlowLayout(ui->plotlistWidget);

    allcolor<<QColor("#f7acbc");
    allcolor<<QColor("#f47920");
    allcolor<<QColor("#7f7522");
    allcolor<<QColor("#2b4490");
    allcolor<<QColor("#ffe600");
    allcolor<<QColor("#843900");
    allcolor<<QColor("#d71345");
    allcolor<<QColor("#72baa7");
    allcolor<<QColor("#7fb80e");
    allcolor<<QColor("#c37e00");
    allcolor<<QColor("#9b95c9");
    allcolor<<QColor("#007d65");
    allcolor<<QColor("#cd9a5b");
    allcolor<<QColor("#94d6da");
    allcolor<<QColor("#bed742");
    allcolor<<QColor("#8552a1");
    allcolor<<QColor("#840228");
    allcolor<<QColor("#72777b");
    allcolor<<QColor("#33a3dc");
    initform();
    setcurveproperty();
    initCurve();

    connect(ui->pushButton_show, &QPushButton::clicked, this, &Plot::pushButton_show_clicked);
    connect(ui->pushButton_hide, &QPushButton::clicked, this, &Plot::pushButton_hide_clicked);
    connect(ui->pushButton_cut, &QPushButton::clicked, this, &Plot::exportRecordChart);
    connect(ui->pushButton_editor, &QPushButton::clicked, this, &Plot::pushButton_editor_clicked);
    // 打开工程加载曲线
//    connect(projectmanager, &ProjectManager::signalOpenProject, this, &Plot::updateCurveInfos);
}

Plot::~Plot()
{
    delete ui;
}

void Plot::initform()
{
    ui->widget->setProperty("form","pad");
    ui->label->setProperty("form","big");
    ui->pushButton_show->setIcon(QIcon(":/image/byzt/shouqi_left.png"));
    ui->pushButton_hide->setIcon(QIcon(":/image/byzt/zhankai_right.png"));
    ui->pushButton_cut->setIcon(QIcon(":/image/byzt/cut.png"));
    ui->pushButton_editor->setIcon(QIcon(":/image/byzt/setproperty.png"));
//    QString style = "background-color: transparent; border: transparent;";
    ui->pushButton_hide->setProperty("form","icon");
    ui->pushButton_show->setProperty("form","icon");
    ui->pushButton_cut->setProperty("form","icon");
    ui->pushButton_editor->setProperty("form","icon");
    ui->rightPad->setVisible(false);
    ui->pushButton_cut->setToolTip("截图");
    ui->pushButton_editor->setToolTip("属性编辑");
}

void Plot::initCurve()
{
    ui->curveWidget->setAcceptDrops(true);   // 设置内容可接收拖拽
    ui->curveWidget->setMouseTracking(true); // 鼠标跟踪
    ui->curveWidget->legend->setVisible(true); // 显示图例
    tracer = new QCPItemTracer(ui->curveWidget);
    // tracer->setInterpolating(false);
    tracer->setStyle(QCPItemTracer::tsCircle);
    tracer->setPen(QPen(Qt::red));
    tracer->setBrush(Qt::red);
    tracer->setSize(6);
    ui->curveWidget->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);

    QSharedPointer<QCPAxisTickerDateTime> dateTicker(new QCPAxisTickerDateTime);// 日期做X轴
    dateTicker->setDateTimeFormat("hh:mm:ss.zzz");// 日期格式(可参考QDateTime::fromString()函数)
    ui->curveWidget->xAxis->setTicker(dateTicker);// 设置X轴为时间轴

    ui->curveWidget->rescaleAxes(true);

    connect(ui->curveWidget, SIGNAL(mousePress(QMouseEvent*)), this, SLOT(mousePressEvent(QMouseEvent*)));
}

void Plot::exportRecordChart()
{
    if(!ui->curveWidget)
    {
        return;
    }
    QTime timeNow = QTime::currentTime();
    QString name=timeNow.toString("hhmmss");

    QString filename = QFileDialog::getSaveFileName(
                this,
                tr("保存的截图文件"),
                name,
                "PDF(*.pdf);;PNG(*.png);;JPG(*.jpg);;JPEG(*.jpeg)"
                );

    if( filename == "" ){
        return;
    }
    if( filename.endsWith(".png") ){
        ui->curveWidget->savePng( filename, ui->curveWidget->width(), ui->curveWidget->height() );
        return;
    }
    if( filename.endsWith(".jpg") ){
        ui->curveWidget->saveJpg( filename, ui->curveWidget->width(), ui->curveWidget->height() );
        return;
    }
    if( filename.endsWith(".jpeg") ){
        ui->curveWidget->saveJpg( filename, ui->curveWidget->width(), ui->curveWidget->height() );
        return;
    }
    if( filename.endsWith(".pdf") ){
        ui->curveWidget->savePdf( filename, ui->curveWidget->width(), ui->curveWidget->height() );
        return;
    }
}

void Plot::updateCurveInfos(CurveInfo m_curveinfo)
{
    cinfo =m_curveinfo;
    setcurveproperty();
}

void Plot::setcurveproperty()
{
    ui->curveWidget->xAxis->setLabel(cinfo.X_label);
    ui->curveWidget->yAxis->setLabel(cinfo.Y_label);
    ui->curveWidget->xAxis->setRange(round(0), round(cinfo.X_Range));
    ui->curveWidget->xAxis->ticker()->setTickCount(cinfo.X_tickcount);
    ui->curveWidget->yAxis->ticker()->setTickCount(cinfo.Y_tickcount);
    ui->curveWidget->xAxis->grid()->setVisible(cinfo.showGrid);
    ui->curveWidget->yAxis->grid()->setVisible(cinfo.showGrid);
    ui->curveWidget->yAxis->setTickLabelPadding(cinfo.Y_labelPadding);
    ui->curveWidget->xAxis->setTickLabelPadding(cinfo.X_labelPadding);
    ui->curveWidget->xAxis->grid()->setPen(QPen(cinfo.gridColor, cinfo.AxisLineWidth / 2, Qt::PenStyle::DashLine));
    ui->curveWidget->yAxis->grid()->setPen(QPen(cinfo.gridColor, cinfo.AxisLineWidth / 2, Qt::PenStyle::DashLine));
    ui->curveWidget->setBackground(cinfo.bgcolor);

    // 支持拖拽和缩放
    if(cinfo.rescale)
    {
        ui->curveWidget->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);
    }
    else
    {
        ui->curveWidget->setInteractions(QCP::iNone);
    }

    QFont font;
    font.setPointSize(cinfo.AxisFontSize);
    ui->curveWidget->xAxis->setTickLabelFont(font);
    ui->curveWidget->yAxis->setTickLabelFont(font);

    int numGraphs = ui->curveWidget->graphCount(); // 获取曲线数量
    for (int i = 0; i < numGraphs; ++i)
    {
        QCPGraph* graph = ui->curveWidget->graph(i);
        QPen pen = graph->pen();
        pen.setWidth(cinfo.lineWidth);
        graph->setPen(pen);
//        graph->setInterpolating(true);
        graph->setAdaptiveSampling(cinfo.smoothed);

        if(cinfo.showPoint)
        {
            graph->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ScatterShape::ssDisc,2));
        }
        else
        {
            graph->setScatterStyle(QCPScatterStyle::ssNone);
        }
    }

    QPen axisPen;
    axisPen.setColor(cinfo.axisColor);
    axisPen.setWidth(cinfo.AxisLineWidth);
    ui->curveWidget->xAxis->setLabelColor(cinfo.axisTxtColor);
    ui->curveWidget->yAxis->setLabelColor(cinfo.axisTxtColor);
    ui->curveWidget->xAxis->setBasePen(axisPen);
    ui->curveWidget->yAxis->setBasePen(axisPen);
    ui->curveWidget->xAxis->setTickLabelColor(cinfo.axisTxtColor);
    ui->curveWidget->yAxis->setTickLabelColor(cinfo.axisTxtColor);
    ui->curveWidget->rescaleAxes(true);

    ui->curveWidget->replot();
}

// 添加曲线，和curvetop的显示
void Plot::addVar(CurveVarInfo varInfo,int col)
{
    for (int i=0;i<ui->curveWidget->graphCount();i++) {
        if(varInfo.name==ui->curveWidget->graph(i)->name())
        {
            return;
        }
    }

    //画曲线
    QCPGraph * tempGraph = ui->curveWidget->addGraph();
    // 给曲线创建颜色 如果初始的颜色都被用完创建随机颜色
    QColor t_color;
    if(allcolor.length()>0)
    {
        t_color=allcolor.takeAt(0);
    }
    else
    {
        //构造一个随机颜色z
        std::default_random_engine e;
        std::uniform_real_distribution<double> random(0,1);
        t_color=QColor::fromRgb(int(random(e)*255),int(random(e)*255),int(random(e)*255));
    }
    QPen pen = QPen(t_color, 2);
    tempGraph->setPen(pen);
    tempGraph->setName(varInfo.name);
    tempGraph->setAdaptiveSampling(true);
    tempGraph->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ScatterShape::ssDisc,4));   
    QVector<double> x(100), y(100);

    // 构建的曲线
        QVector<double> q(100), p(100);
        for (int i = 0; i < 100; ++i)
        {
            double n = qrand() % 5;    //产生5以内的随机数
            double m = qrand() % 100;
            q[i] = m;
            p[i] = n;
        }
        tempGraph->setAdaptiveSampling(true);
        tempGraph->setData(q, p);
        tempGraph->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ScatterShape::ssDisc,4));
        ui->curveWidget->replot();

    // 创建曲线变量
    CurveVarInfo t_varInfo;
    t_varInfo=varInfo;
    t_varInfo.color=t_color;
    t_varInfo.curveGraph=tempGraph;

    // 创建listwidget中的控件
    ZCurvetop *a = new ZCurvetop;
    a->setStyleSheet("background-color: #2e394f; border-radius: 8px;");
    a->settext(t_varInfo.name);
    a->setcolorlabel(t_color);
    flowLayout->addWidget(a);

    // 插入所有变量map中
    curvedata.insert(a,t_varInfo);
    // 消隐信号触发隐藏显示绘制的操作
    connect(a, &ZCurvetop::signalHideVar, this, &Plot::hideShowvar);
    connect(a, &ZCurvetop::signalDelete, this, &Plot::deleteVar);


    emit signalUpdateGraph(tempGraph,col);
}

void Plot::hideShowvar(bool check)
{
    // 触发指针
    ZCurvetop * m_sender=(ZCurvetop *)sender();

    // 如果所有变量中不包含m_sender则返回
    if(!curvedata.contains(m_sender)){return;}

    CurveVarInfo t_varInfo=curvedata.value(m_sender);

    if (check)
    {
        QCPGraph * tempGraph=t_varInfo.curveGraph;
        tempGraph->setVisible(true);
        if (flag2Graph.contains(tempGraph))
        {
            auto &labels = flag2Graph[tempGraph];
            for (auto label : labels)
            {
                if (label)
                {
                    label->setVisible(true);
                }
            }
        }
        if (tracer && tracer->graph() == tempGraph)
        {
            tracer->setVisible(true);
        }
    }

    else if (!check)
    {
        QCPGraph * tempGraph=curvedata.value(m_sender).curveGraph;
        if(!tempGraph){return;}
        tempGraph->setVisible(false);
        if (flag2Graph.contains(tempGraph))
        {
            auto &labels = flag2Graph[tempGraph];
            for (auto label : labels)
            {
                if (label)
                {
                    label->setVisible(false);
                }
            }
        }
        //跟踪器也要隐藏 不然会留下坐标点
        if (tracer && tracer->graph() == tempGraph)
        {
            tracer->setVisible(false);
        }
    }
    curvedata[m_sender]=t_varInfo;

    ui->curveWidget->replot();
}

void Plot::deleteVar()
{
    // 触发指针
    ZCurvetop * m_sender=(ZCurvetop *)sender();

    // 如果所有变量中不包含m_sender则返回
    if(!curvedata.contains(m_sender)){return;}
    CurveVarInfo temp_varInfo=curvedata.value(m_sender);

    QCPGraph * tempGraph=curvedata.value(m_sender).curveGraph;
    if(!tempGraph){return;}

    // 删除对应标签
    if (flag2Graph.contains(tempGraph))
    {
        auto &labels = flag2Graph[tempGraph];
        for (auto label : labels)
        {
            if (label)
            {
                label->setVisible(false);
                delete label;
            }
        }
        flag2Graph.remove(tempGraph);
    }

    // 如果跟踪器关联到该曲线，删除跟踪器
    if (tracer && tracer->graph() == tempGraph)
    {
        tracer->setVisible(false); // 隐藏跟踪器
        tracer->setGraph(nullptr); // 解除跟踪器与图形的关联
        tracer->deleteLater(); // 删除跟踪器
        tracer = nullptr; // 解除跟踪器指针
    }

    ui->curveWidget->removeGraph(tempGraph);
    ui->curveWidget->replot();

    curvedata.remove(m_sender);
    allcolor.append(temp_varInfo.color);

    flowLayout->removeWidget(m_sender);
    m_sender->deleteLater();

}

// 实现接受拖放操作
void Plot::dragEnterEvent(QDragEnterEvent * event) {
    if(event->mimeData()->hasFormat("application/x-qabstractitemmodeldatalist"))
    {
        event->accept();  //接受拖动
    }
    else{
        event->ignore();  //忽略拖动
    }
}

void Plot::dragMoveEvent(QDragMoveEvent * event) {
    if (event->mimeData()->hasFormat("application/x-qabstractitemmodeldatalist"))
    {
        event->accept();
    }
    else{
        event->ignore();
    }
}

// 提取拖放数据 解析并获取数据
void Plot::dropEvent(QDropEvent * event) {
    // 从 mimeData 中提取数据流
    QByteArray arr = event->mimeData()->data("application/x-qabstractitemmodeldatalist");
    QVector<QMap<int, QVariant>> data; //节点的基它的属性
    QDataStream stream(&arr,QIODevice::ReadOnly);

    // 解析数据流，提取节点的行、列和属性数据
    while (!stream.atEnd())
    {
        int r, c;
        QMap<int,QVariant> itemdata;
        stream >> r >> c >> itemdata;
        data.append(itemdata);
    }
    CurveVarInfo varInfo;
    int columIndex;
    if (!data.isEmpty())
    {
        QMap<int, QVariant> v = data.first(); // 假设只获取第一个节点的属性

        int nodeType=v.value(Qt::UserRole+ROLE_TYPE).toInt();
        columIndex=v.value(Qt::UserRole + ROLE_EXTRA+1).toInt();
        if(nodeType!=Field&&nodeType!=BLOCKDISCRETE&&nodeType!=BLOCKANALOG)
        {
            return;
        }

        // 提取节点属性并存储到 varInfo 结构中
        varInfo.name = v.value(0).toString();
        varInfo.size = v.value(1).toString();
        varInfo.type = v.value(2).toString();
        varInfo.offset = v.value(3).toString();
        varInfo.color = v.value(4).toString();
        varInfo.uuid = v.value(6).toString();
    }
    addVar(varInfo,columIndex); //解析完后 添加进画布中
}

void Plot::mousePressEvent(QMouseEvent *e)
{
    QCPGraph* graph = qobject_cast<QCPGraph*>(ui->curveWidget->plottableAt(e->pos(), true));
    QPointF pressPos(0, 0); // 跟踪鼠标点击事件点击位置
    QRect rect(0, 0, 1, 1);
    int dataIndex = 0;
    double key = 0, value = 0;

    if (e->button() == Qt::LeftButton) { // 判断鼠标左键点击,增加标签
        QCPItemText* m_sameTimeTextTip = nullptr;

        if (graph) {

            // 初始化或使用已存在的追踪器 `tracer`
            if (tracer == NULL) {
                tracer = new QCPItemTracer(ui->curveWidget);
                tracer->setParent(ui->curveWidget);
                tracer->setPen(QColor(255, 255, 255));
                tracer->setBrush(QBrush(QColor(255, 0, 0), Qt::SolidPattern));
                tracer->setStyle(QCPItemTracer::tsCircle);
                tracer->setSize(10);
                tracer->setVisible(false);
            }

            // 初始化或使用已存在的文本标签 `m_sameTimeTextTip`
            if (m_sameTimeTextTip == NULL) {
                m_sameTimeTextTip = new QCPItemText(ui->curveWidget);
                m_sameTimeTextTip->setSelectable(false);
                m_sameTimeTextTip->setPositionAlignment(Qt::AlignTop | Qt::AlignLeft);
                m_sameTimeTextTip->position->setType(QCPItemPosition::ptPlotCoords);
                m_sameTimeTextTip->position->setAxes(ui->curveWidget->xAxis, ui->curveWidget->yAxis);
                QFont font;
                font.setPixelSize(12);
                m_sameTimeTextTip->setFont(font);
                m_sameTimeTextTip->setColor(graph->pen().color());
                m_sameTimeTextTip->setPen(graph->pen());
                m_sameTimeTextTip->setBrush(graph->brush());
                m_sameTimeTextTip->setVisible(false);
            }

            QPoint p;
            double posKey;
            p.setX(e->pos().x());
            p.setY(e->pos().y());

            // 判断计算点击位置最近的数据点
            for (int k = graph->data()->dataRange().begin(); k < graph->data()->dataRange().end(); k++) {
                dataIndex = k;
                key = graph->data()->at(k)->key;
                value = graph->data()->at(k)->value;
                posKey = ui->curveWidget->xAxis->coordToPixel(key);

                if (qAbs(posKey - e->pos().x()) <= 10) {
                    double posx = graph->keyAxis()->coordToPixel(key);
                    double posy = graph->valueAxis()->coordToPixel(value);
                    rect.setRect(posx - 10, posy - 10, 21, 21);

                    if (!rect.contains(e->pos())) {
                        continue;
                    }
                    else {
                        break;
                    }
                }

                if (posKey - e->pos().x() > 10) {
                    break;
                }
            }

            // 如果在有效数据点上点击，显示追踪器和标签
            if (!graph->realVisibility()) {
                tracer->setVisible(false);
                pressPos.setX(0);
                pressPos.setY(0);
                ui->curveWidget->replot();
            }
            else if (rect.contains(e->pos())) {
                tracer->setGraph(graph);
                tracer->setGraphKey(key);
                tracer->setVisible(true);
                pressPos.setX(key);
                pressPos.setY(value);
                ui->curveWidget->replot();
            }
            else {
                if (tracer->visible()) {
                    tracer->setVisible(false);
                    pressPos.setX(0);
                    pressPos.setY(0);
                    ui->curveWidget->replot();
                }
            }

            QString tKey = QString("(%1,%2,%3,%4)").arg(QDateTime::fromMSecsSinceEpoch((pressPos.x() * 1000)).toString("hh:mm:ss.zzz")).arg(pressPos.y()).arg(dataIndex).arg(graph->name());

            if (!flagContainer.contains(tKey)) {
                m_sameTimeTextTip->setText("X: " + QDateTime::fromMSecsSinceEpoch((pressPos.x() * 1000)).toString("hh:mm:ss.zzz") + "\nY: " + QString::number(pressPos.y(), 'f', 3));
                m_sameTimeTextTip->position->setCoords(pressPos.x(), pressPos.y());
                m_sameTimeTextTip->setVisible(true);
                flagContainer.insert(tKey, m_sameTimeTextTip);

                if (flag2Graph.contains(graph)) {
                    flag2Graph[graph].insert(dataIndex, m_sameTimeTextTip);
                }
                else {
                    QMap<int, QCPItemText*> tempM;
                    tempM.insert(dataIndex, m_sameTimeTextTip);
                    flag2Graph.insert(graph, tempM);
                }

                ui->curveWidget->replot();
            }
            else {
                if (m_sameTimeTextTip != NULL) {
                    m_sameTimeTextTip->setVisible(false);
                    ui->curveWidget->replot();
                }
            }
        }
        else {
            if (!(tracer == NULL)) {
                if (tracer->visible()) {
                    tracer->setVisible(false);
                    pressPos.setX(0);
                    pressPos.setY(0);
                    ui->curveWidget->replot();
                }
            }
        }
    }

    if (e->button() == Qt::RightButton) { // 判断鼠标右键右键
        QPoint p;
        double posKey;
        p.setX(e->pos().x());
        p.setY(e->pos().y());

        if (graph) {
            // 判断计算点击位置最近的数据点
            for (int k = graph->data()->dataRange().begin(); k < graph->data()->dataRange().end(); k++) {
                dataIndex = k;
                key = graph->data()->at(k)->key;
                value = graph->data()->at(k)->value;
                posKey = ui->curveWidget->xAxis->coordToPixel(key);

                if (qAbs(posKey - e->pos().x()) <= 10) {
                    double posx = graph->keyAxis()->coordToPixel(key);
                    double posy = graph->valueAxis()->coordToPixel(value);
                    rect.setRect(posx - 10, posy - 10, 21, 21);

                    if (!rect.contains(e->pos())) {
                        continue;
                    }
                    else {
                        break;
                    }
                }

                if (posKey - e->pos().x() > 10) {
                    break;
                }
            }

            if (rect.contains(e->pos())) {
                pressPos.setX(key);
                pressPos.setY(value);
                QString tKey = QString("(%1,%2,%3,%4)").arg(QDateTime::fromMSecsSinceEpoch((pressPos.x() * 1000)).toString("hh:mm:ss.zzz")).arg(pressPos.y()).arg(dataIndex).arg(graph->name());

                if (flagContainer.contains(tKey)) {
                    // qDebug()<<tKey;
                    flagContainer[tKey]->setVisible(false);
                    delete flagContainer[tKey];
                    flagContainer[tKey] = nullptr;
                    flagContainer.remove(tKey);
                    flag2Graph[graph].remove(dataIndex);
                }
            }
        }
    }
}

void Plot::pushButton_show_clicked()
{
    ui->leftPad->setVisible(true);
    ui->rightPad->setVisible(false);
    ui->listwidget->setVisible(true);
}

void Plot::pushButton_hide_clicked()
{
    ui->leftPad->setVisible(false);
    ui->rightPad->setVisible(true);
    ui->listwidget->setVisible(false);
}

void Plot::pushButton_editor_clicked()
{
    emit sigShow(1);
    ZCurveProperty *w = new ZCurveProperty(nullptr, cinfo);
    w->setWindowFlags(Qt::FramelessWindowHint| Qt::WindowStaysOnTopHint);
    connect(w, &QDialog::finished, this, [=]() {
        emit sigShow(0);
    });
    w->show();

    connect(w,&ZCurveProperty::signalToSubmit,this,&Plot::updateCurveInfos);
}

void Plot::setCurName(QString name){
    ui->label->setText(name);
    ui->label->setProperty("form","big");
}
