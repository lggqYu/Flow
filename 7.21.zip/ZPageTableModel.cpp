﻿#include "ZPageTableModel.h"


ZPageTableModel::ZPageTableModel(QList<QList<QVariant>> data,QObject *parent)
    : QAbstractTableModel{parent}
    , m_data(data)
    , m_totalRows(data.size())
{
    m_perPage = m_totalRows;
    m_currentPage = 0;

    for (int i = 0; i < m_data.length(); ++i) {
        QList<bool> m;
        QList<float> f;
        QList<QString> s;
        for (int j = 0; j < m_data.first().length(); ++j) {
            m.append(false);
            f.append(0.0f);
            s.append("");
        }
        m_checkData.append(m);
        m_ProgressData.append(f);
        m_BindCurve.append(s);
    }

}

int ZPageTableModel::rowCount(const QModelIndex& parent) const
{
    Q_UNUSED(parent);

    // 计算当前页的行数
    int rows = qMin(m_perPage, m_totalRows - m_currentPage * m_perPage);

    // 如果当前页的行数小于0，说明已经没有数据需要显示，返回0
    if (rows <= 0) {
        return 0;
    }

    return rows;
}

int ZPageTableModel::columnCount(const QModelIndex& parent ) const
{
    if (m_data.isEmpty())
        return 0;
    return m_data.first().size();
}

QVariant ZPageTableModel::data(const QModelIndex& index, int role) const
{
    if (!index.isValid()) {
        return QVariant();
    }

    // 计算当前行在原始数据中的位置
    int row = m_currentPage * m_perPage + index.row();

    // 如果行号超出了原始数据的范围，返回空值
    if (row < 0 || row >= m_totalRows) {
        return QVariant();
    }

    // 根据角色返回数据
    if (role == Qt::DisplayRole || role == Qt::EditRole ) {
        QVariant value=m_data[row][index.column()];
        if(value.type()==QVariant::StringList)
        {
            if(value.toStringList().length()>0)
            {
                return value.toStringList()[0];
            }
        }
        else
        {
            return m_data[row][index.column()];
        }
    }
    else if (role == Qt::UserRole+30) {
        QVariant value=m_data[row][index.column()];
        if (value.type() == QVariant::StringList) {
            return value.toStringList();  // 返回整个 QStringList
        }
    }
    else if (role == Qt::UserRole+20 && index.column()>1){
        return m_BindCurve[row][index.column()];
    }
    else if (role == Qt::UserRole+12 && index.column()>1){
        return m_ProgressData[row][index.column()];
    }

    else if (role == Qt::UserRole+11 && index.column()>1){
        return m_checkData[row][index.column()] ? true : false;
    }
    else if (role == Qt::TextAlignmentRole){
        return Qt::AlignCenter;
    }

    return QVariant();
}

bool ZPageTableModel::setData(const QModelIndex& index, const QVariant & value, int role){
    if (!index.isValid()) {
        return false;
    }

    // 计算当前行在原始数据中的位置
    int row = m_currentPage * m_perPage + index.row();


    // 如果行号超出了原始数据的范围，返回空值
    if (row < 0 || row >= m_totalRows) {
        return false;
    }

    if (role == Qt::DisplayRole|| role == Qt::EditRole || role == Qt::DecorationRole)
    {
         m_data[row][index.column()]=value;
//        emit dataChanged(index, index, {role});
    }

    else if (role == Qt::UserRole+20&& index.column()>1)
    {
        m_BindCurve[row][index.column()]=value.toString();
    }

    else if (role == Qt::UserRole+12&& index.column()>1)
    {
        m_ProgressData[row][index.column()]=value.toFloat();
    }

    else if (role == Qt::UserRole+11 && index.column()>1){
        m_checkData[row][index.column()] = value.toBool();
    }



    return true;
}

int ZPageTableModel::perPage() const
{
    return m_perPage;
}

void ZPageTableModel::setPerPage(int newPerPage)
{
    if (m_perPage == newPerPage)
        return;
    m_perPage = newPerPage;
    m_currentPage = 0;
    emit layoutChanged();
}

void ZPageTableModel::setCurrentPage(int newCurrentPage)
{
    if (newCurrentPage < 0 || newCurrentPage >= pageCount()) {
        return;
    }

    m_currentPage = newCurrentPage;
    emit layoutChanged();
}

int ZPageTableModel::currentPage() const
{
    return m_currentPage;
}

int ZPageTableModel::pageCount() const
{
    return (m_totalRows + m_perPage - 1) / m_perPage;
}

void ZPageTableModel::setHeaderLabels(QStringList list){
    m_headerLabels = list;
}

QVariant ZPageTableModel::headerData(int section, Qt::Orientation orientation, int role) const{
    if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
    {
        return m_headerLabels.value(section);
    }
    return QVariant();
}

Qt::ItemFlags ZPageTableModel::flags(const QModelIndex& index) const{
    if (!index.isValid())
    {
        return Qt::NoItemFlags;
    }
    return Qt::ItemIsUserCheckable | Qt::ItemIsEditable | QAbstractTableModel::flags(index);
}

QList<QVariant> ZPageTableModel::getColumnData(int col){
    if (m_data.isEmpty() || col < 0){
        return QList<QVariant>();
    }
    else{
        QList<QVariant> data = m_data[0];
        if (col >= data.length()){
            return QList<QVariant>();
        }
        QList<QVariant> res;
        for(int i = 0; i < m_data.length(); i++){
            res.append(m_data[i][col]);
        }
        return res;
    }
}



QList<QList<bool>> ZPageTableModel::getCheckState(){
    return m_checkData;
}



void ZPageTableModel::setAllData(QList<QList<QVariant>>& data){
    m_currentPage = 0;
    m_data = data;
    m_checkData.clear();
    m_ProgressData.clear();
    m_totalRows = data.size();    //   8.14 add
    m_perPage = m_totalRows;

    for (int i = 0; i < m_data.length(); ++i) {
        QList<bool> m;
        QList<float> f;
        QList<QString> s;
        for (int j = 0; j < m_data.first().length(); ++j) {
            m.append(false);
            f.append(0.0f);
            s.append("");
        }
        m_checkData.append(m);
        m_ProgressData.append(f);
        m_BindCurve.append(s);
    }
    emit layoutChanged();
}

void ZPageTableModel::appendData(QList<QVariant> &data)
{
    m_data.append(data);
    m_totalRows = m_data.size();  // 更新行数
    m_perPage = m_totalRows;
    emit layoutChanged();
}

void ZPageTableModel::clearData()
{
    m_data.clear();
    m_checkData.clear();
    m_ProgressData.clear();
    m_BindCurve.clear();
}
