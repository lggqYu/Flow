﻿#ifndef ZPAGETABLEMODEL_H
#define ZPAGETABLEMODEL_H

#include <QAbstractTableModel>
#include <QDebug>

class ZPageTableModel : public QAbstractTableModel
{
    Q_OBJECT
    Q_PROPERTY(int perPage READ perPage WRITE setPerPage NOTIFY perPageChanged)
    Q_PROPERTY(int currentPage READ currentPage WRITE setCurrentPage NOTIFY currentPageChanged)
public:
    explicit ZPageTableModel(QList<QList<QVariant>> data = QList<QList<QVariant>>(),QObject *parent = nullptr);

    int rowCount(const QModelIndex& parent = QModelIndex()) const override;
    int columnCount(const QModelIndex& parent = QModelIndex()) const override;
    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const override;
    Qt::ItemFlags flags(const QModelIndex& index) const override;
    bool setData(const QModelIndex& index, const QVariant & value, int role) override;

    QList<QVariant> getColumnData(int col);  //获取第几列的数据
    QList<QList<bool>> getCheckState();  //获取check状态
    int perPage() const;
    void setPerPage(int newPerPage);
    int currentPage() const;
    int pageCount() const;
    void setCurrentPage(int newCurrentPage);
    void setHeaderLabels(QStringList list); //表头
    QVariant headerData(int section, Qt::Orientation orientation, int role) const override;
    void setAllData(QList<QList<QVariant>>& data);
    void appendData(QList<QVariant>& data);
    void clearData();
signals:
    void perPageChanged();
    void currentPageChanged();

private:
    QList<QList<QVariant>> m_data;//数据
    int m_perPage;    //每页显示的个数
    int m_totalRows;  //总共的行数
    int m_currentPage;
    QStringList  m_headerLabels;
    QList<QList<bool>> m_checkData;
    QList<QList<float>> m_ProgressData;
    QList<QList<QString>> m_BindCurve;
};

#endif // ZPAGETABLEMODEL_H
