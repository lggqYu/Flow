﻿#include "CustomMessageBox.h"

CustomMessageBox::CustomMessageBox(QWidget *parent)
    : QMessageBox(parent)
{
    // 你可以在这里做一些自定义的初始化
}

QMessageBox::StandardButton CustomMessageBox::showMessageBox(QWidget *parent,
                                                             QMessageBox::Icon icon,
                                                             const QString &title,
                                                             const QString &text,
                                                             QMessageBox::StandardButtons buttons)
{
    CustomMessageBox msgBox(parent);  // 使用自定义的消息框类
    msgBox.setIcon(icon);
    msgBox.setWindowTitle(title);
    msgBox.setText(text);
    msgBox.setStandardButtons(buttons);
    msgBox.setWindowFlags(msgBox.windowFlags() | Qt::WindowStaysOnTopHint);

    // 设置样式
    msgBox.setStyleSheet(
        "QMessageBox { background-color: #1e2337; }"          // 设置对话框背景颜色
        "QLabel { color: #ffffff; font-size: 14px; }"          // 设置标签的字体颜色和大小
        "QPushButton { background-color: #363c59; color: white; border-radius: 5px; padding: 6px 12px; min-width: 60px; }" // 设置按钮样式
        "QPushButton:hover { background-color: #0282bd; }"     // 设置按钮悬停效果
    );

    return static_cast<QMessageBox::StandardButton>(msgBox.exec());  // 强制转换为 StandardButton
}
