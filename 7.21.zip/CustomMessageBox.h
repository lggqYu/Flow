﻿#ifndef CUSTOMMESSAGEBOX_H
#define CUSTOMMESSAGEBOX_H


#include <QMessageBox>
#include <QWidget>
#include <QString>

class CustomMessageBox : public QMessageBox
{
public:
    // 构造函数
    explicit CustomMessageBox(QWidget *parent = nullptr);

    // 显示消息框的函数
    static QMessageBox::StandardButton showMessageBox(QWidget *parent,
                                                      QMessageBox::Icon icon,
                                                      const QString &title,
                                                      const QString &text,
                                                      QMessageBox::StandardButtons buttons = QMessageBox::Ok);
};

#endif // CUSTOMMESSAGEBOX_H
