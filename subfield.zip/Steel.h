#pragma once
#ifndef __STEEL_H__
#define __STEEL_H__
class Steel
{
    private:
	    float pho;
	    float ce;
	    float lambda;
    public:
	    void setphysicialparameters(float);
	    friend class Temperature;
	    friend class Temperature1d;
	    friend class Temperature2d;
	    friend class TemperatureGPU;
};
#endif // !__STEEL_H__