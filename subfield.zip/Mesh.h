#pragma once
#ifndef  __MESH_H__
#define __MESH_H__

class Mesh
{
    public:
	    int nx, ny, nz;
	    int tnpts;
	    float lx, ly, lz;
	    float tf;
	    float dx, dy, dz;
	    float tau;
	    Mesh(int, int, int, int, float, float, float, float);
	    void print();
};

#endif // ! __MESH_H__