#include "ContinuousCaster.h"
#include <iostream>
using namespace std;
ContinuousCaster::ContinuousCaster(int section, int coolsection, int moldsection, float* sectionlength)
{
	this->section = section;
	this->coolsection = coolsection;
	this->moldsection = moldsection;
	this->sectionlength = new float[section + 1];
	for (int i = 0; i < section + 1; i++)
		this->sectionlength[i] = sectionlength[i];
}

ContinuousCaster::~ContinuousCaster()
{
	delete[] sectionlength;
}

void ContinuousCaster::print()
{
	cout << "section = " << section << " ";
	cout << "coolsection = " << coolsection << " ";
	cout << "moldsection = " << moldsection << " " << endl;
	for (int i = 0; i < section; i++)
		cout << sectionlength[i] << ", ";
}