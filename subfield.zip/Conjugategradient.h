#pragma once
#ifndef __CONJUGATEGRADIENT_H__
#define __CONJUGATEGRADIENT_H__
#include "ContinuousCaster.h"
#include "Gradientbasedalgorithm.h"
class Conjugategradient :public Gradientbasedalgorithm
{
    public:
	    float * dk_1;
	    float *gradient_1;
	    float beta;
	    Conjugategradient(ContinuousCaster &, float*);
	    ~Conjugategradient();
	    virtual void computesearchdirection();
};
#endif // !__CONJUGATEGRADIENT_H__