#include "Conjugategradient.h"
#include <math.h>
#include <iostream>
#include <fstream>
using namespace std;
Conjugategradient::Conjugategradient(ContinuousCaster & CasterOne, float* m_taimmeantemperature) :Gradientbasedalgorithm(CasterOne, m_taimmeantemperature)
{
	dk_1 = new float[coolsection];
	gradient_1 = new float[coolsection];
}

Conjugategradient::~Conjugategradient()
{
	delete[] dk_1;
	delete[] gradient_1;
}

void Conjugategradient::computesearchdirection()
{
	float beta1, beta2;
	if (iter_time == 0)
	{
		for (int i = 0; i < coolsection; i++)
			dk[i] = gradient[i];
	}
	else
	{
		beta1 = 0;
		beta2 = 0;
		for (int i = 0; i < coolsection; i++)
		{
			beta1 += gradient[i] * gradient[i];
			beta2 += gradient_1[i] * gradient_1[i];
		}
		beta = beta1 / beta2;
		for (int i = 0; i < coolsection; i++)
			dk[i] = gradient[i] - beta * dk_1[i];
	}
	for (int i = 0; i < coolsection; i++)
	{
		dk_1[i] = dk[i];
		gradient_1[i] = gradient[i];
	}
	
}
