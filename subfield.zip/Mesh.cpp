
#include <iostream>
#include "Mesh.h"
using namespace std;
Mesh::Mesh(int m_nx, int m_ny, int m_nz, int m_tnpts, float m_tf, float m_lx, float m_ly, float m_lz)
{
	nx = m_nx;
	ny = m_ny;
	nz = m_nz;
	tnpts = m_tnpts;
	tf = m_tf;
	lx = m_lx;
	ly = m_ly;
	lz = m_lz;
	dx = m_lx / float(m_nx - 1);
	dy = m_ly / float(m_ny - 1);
	dz = m_lz / float(m_nz - 1);
	tau = m_tf / float(m_tnpts - 1);
}

void Mesh::print()
{
	cout << "nx = " << nx << ", ";
	cout << "ny = " << ny << ", ";
	cout << "nz = " << nz << ", ";
	cout << "lx = " << lx << ", ";
	cout << "ly = " << ly << ", ";
	cout << "lz = " << lz << ", ";
	cout << "dx = " << dx << ", ";
	cout << "dy = " << dy << ", ";
	cout << "dz = " << dz << ", ";
	cout << "tnpts = " << tnpts << ", ";
	cout << "tau = " << tau << ", ";
	cout << "tf = " << tf << ", ";
}