#include "Steel.h"
void Steel::setphysicialparameters(float T)
{
	float Ts = 1462.0, Tl = 1518.0, lambdas = 30, lambdal = 50, phos = 7000, phol = 7500, cel = 540.0, L = 265600.0, fs = 0.0;
	if (T < Ts)
	{
		fs = 0;
		pho = phos;
		lambda = lambdas;
		ce = cel;
	}

	if (T >= Ts && T <= Tl)
	{
		fs = (T - Ts) / (Tl - Ts);
		pho = fs * phos + (1 - fs) * phol;
		lambda = fs*lambdas + (1 - fs) * lambdal;
		ce = cel + L / (Tl - Ts);
	}

	if (T > Tl)
	{
		fs = 1;
		pho = phol;
		lambda = lambdal;
		ce = cel;
	}
}