#include "Gradientbasedalgorithm.h"
//#include "Temperature1d.h"
//#include "Temperature2d.h"
#include "Temperature.h"
#include <math.h>
#include <iostream>
#include <fstream>
using namespace std;
Gradientbasedalgorithm::Gradientbasedalgorithm(ContinuousCaster & CasterOne, float* m_taimmeantemperature)
{
	mCasterOne = &CasterOne;
	coolsection = mCasterOne->coolsection;
	iter_time = 0;
	allmeantemperature = new float*[mCasterOne->coolsection];
	for (int i = 0; i < mCasterOne->coolsection; i++)
		allmeantemperature[i] = new float[coolsection];
	Jacobian = new float*[mCasterOne->coolsection];
	for (int i = 0; i < mCasterOne->coolsection; i++)
		Jacobian[i] = new float[coolsection];
	staticmeantemperature = new float[coolsection];
	gradient = new float[coolsection];
	dk = new float[coolsection];
	weight = new float[coolsection];
	taimmeantemperature = new float[coolsection];
	for (int i = 0; i < mCasterOne->coolsection; i++)
		taimmeantemperature[i] = m_taimmeantemperature[i];
}

Gradientbasedalgorithm::~Gradientbasedalgorithm()
{
	for (int i = 0; i < mCasterOne->coolsection; i++)
		delete[] allmeantemperature[i];
	delete[] allmeantemperature;
	for (int i = 0; i < mCasterOne->coolsection; i++)
		delete[] Jacobian[i];
	delete[] Jacobian;
	delete[] taimmeantemperature;
	delete[] staticmeantemperature;
	delete[] gradient;
	delete[] dk;
	delete[] weight;
}

void Gradientbasedalgorithm::computegradient()
{
	for (int i = 0; i < coolsection; i++)
		for (int j = 0; j < coolsection; j++)
			Jacobian[i][j] = (allmeantemperature[i][j] - staticmeantemperature[j]) / dh;
	for (int i = 0; i < coolsection; i++)
	{
		gradient[i] = 0.0;
		for (int j = 0; j < coolsection; j++)
			gradient[i] += weight[i] * (taimmeantemperature[j] - staticmeantemperature[j]) * Jacobian[i][j];
	}
}

void Gradientbasedalgorithm::computesearchdirection()
{
	for (int i = 0; i < coolsection; i++)
		dk[i] = gradient[i];
}

void::Gradientbasedalgorithm::linesearch()
{
	float step1 = 0.0f, step2 = 0.0f, eps = 0.10f;
	for (int i = 0; i < coolsection; i++)
		for (int j = 0; j < coolsection; j++)
		{
			step1 += weight[i] * (staticmeantemperature[i] - taimmeantemperature[i]) * Jacobian[i][j];
			step2 += Jacobian[i][j] * dk[j] * Jacobian[i][j] * dk[j];
		}
	step = fabs(step1 / (step2 + eps));
}

void::Gradientbasedalgorithm::updateh(float* hresult)
{
	for (int i = 0; i < coolsection; i++)
		hresult[i + mCasterOne->moldsection] = hresult[i + mCasterOne->moldsection] + step * dk[i];
	costvalue.push_back(0.0f);
	for (int i = 0; i < coolsection; i++)
		costvalue.back() += weight[i] * (staticmeantemperature[i] - taimmeantemperature[i]) * (staticmeantemperature[i] - taimmeantemperature[i]) / coolsection;
	costvalue.back() = sqrt(costvalue.back() / coolsection);
	iter_time++;
}

void Gradientbasedalgorithm::init(float**m_allmeantemperature, float *m_staticmeantemperature, float m_dh)
{
	dh = m_dh;
	for (int i = 0; i < coolsection; i++)
		for (int j = 0; j < coolsection; j++)
			allmeantemperature[i][j] = m_allmeantemperature[i][j];
	for (int i = 0; i < coolsection; i++)
		staticmeantemperature[i] = m_staticmeantemperature[i];
	for (int i = 0; i < coolsection; i++)
		weight[i] = 1.0f;
}

void::Gradientbasedalgorithm::validation(float*m_measuredtemperaturetemp, float*hinit, float*htemp)
{
	float msetemperature = 0.0;
	for (int i = 0; i < coolsection; i++)
		msetemperature += (m_measuredtemperaturetemp[i] - staticmeantemperature[i]) * (m_measuredtemperaturetemp[i] - staticmeantemperature[i]);

	float mseh = 0.0;
	for (int i = 0; i < coolsection; i++)
		mseh += (hinit[i + mCasterOne->moldsection] - htemp[i + mCasterOne->moldsection]) * (hinit[i + mCasterOne->moldsection] - htemp[i + mCasterOne->moldsection]);
	cout << "mseh = " << mseh << ", ";
	cout << "msetemperature = " << msetemperature << endl;
}

void Gradientbasedalgorithm::print()
{
	cout << "staticmeantemperature - taimmeantemperature = " << endl;
	for (int i = 0; i < coolsection; i++)
		cout << fabs(staticmeantemperature[i] - taimmeantemperature[i]) << ", ";
	cout << endl;

	cout << "Gradient = ";
	for (int i = 0; i < coolsection; i++)
		cout << gradient[i] << ", ";
	cout << endl;
	cout << "step = " << step << endl;
	cout << "itertime = " << iter_time << endl;
	cout << "costvalue = " << costvalue.back() << endl;
}

//void Gradientbasedalgorithm::outputdata(Temperature1d & m_SteelTemperature)
//{
//	ofstream outputfile;
//	outputfile.open("C:\\costvalue.txt", ios::app);
//	outputfile.close();
//	outputfile.open("C:\\surfacetemperature.txt", ios::app);
//	for (int i = 0; i < m_SteelTemperature.tnpts; i++)
//		outputfile << (m_SteelTemperature.T_Surface[i]) << endl;
//	outputfile.close();
//	/*if (m_tstep % 10 == 0)
//	{
//	outputfile.open("C:\\SteelTemperatureData.txt", ios::app);
//	outputfile << m_tstep << endl;
//	outputfile << step << ", " << costvalue << endl;
//	for (int i = 0; i < coolsection; i++)
//	outputfile << staticmeantemperature[i] << ", ";
//	outputfile << endl;
//	for (int i = 0; i < coolsection; i++)
//	outputfile << (staticmeantemperature[i] - taimmeantemperature[i]) << ", ";
//	outputfile << endl;
//	for (int i = 0; i < coolsection; i++)
//	outputfile << gradient[i] << ", ";
//	outputfile << endl;
//	for (int i = 0; i < coolsection; i++)
//	outputfile << hinit[i + mCasterOne->moldsection] << ", ";
//	outputfile << endl;
//	outputfile << endl;
//	outputfile.close();
//	}*/
//
//}

void Gradientbasedalgorithm::outputdata(Temperature & m_SteelTemperature, float* h_init)
{
	ofstream outputfile;
	outputfile.open("D:\\surfacetemperature.csv", ios::app);
	for (int i = 0; i < m_SteelTemperature.ny; i++)
		outputfile << m_SteelTemperature.T_Surface[i] << ",";
	outputfile << endl;
	outputfile.close();

	outputfile.open("D:\\meantemperature.csv", ios::app);
	outputfile << m_SteelTemperature.tstep << "," << costvalue.back() << ",";
	for (int i = 0; i < coolsection; i++)
		outputfile << staticmeantemperature[i] << ",";
	for (int i = 0; i < coolsection; i++)
		outputfile << (staticmeantemperature[i] - taimmeantemperature[i]) << ",";
	for (int i = 0; i < coolsection; i++)
		outputfile << h_init[i + mCasterOne->moldsection] << ",";
	for (int i = 0; i < coolsection; i++)
		outputfile << gradient[i] << ",";
	outputfile << endl;
	outputfile.close();
}