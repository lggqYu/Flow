#pragma once
#ifndef __GRADIENTBASEDALGORITHM_H__
#define __GRADIENTBASEDALGORITHM_H__
#include "ContinuousCaster.h"
#include "Steel.h"
#include "vector"
using namespace std;
class Gradientbasedalgorithm
{
    public:
	    int coolsection;
	    int iter_time;
	    float** allmeantemperature;
	    float* staticmeantemperature;
	    float* taimmeantemperature;
	    float** Jacobian;
	    float* gradient;
	    float* dk;
	    float* weight;
		vector<float> costvalue;
	    float dh;
	    float step;
	    ContinuousCaster* mCasterOne;
	    Gradientbasedalgorithm(ContinuousCaster &, float*);
	    ~Gradientbasedalgorithm();
	    void computegradient();
		virtual void computesearchdirection();
	    void init(float**, float*, float);
	    void linesearch();
	    void updateh(float*);
	    void validation(float*, float*, float*);
	    void print();
	    void outputdata(Temperature1d&);
		void outputdata(Temperature& m_SteelTemperature, float* h_init);
};
#endif // !__GRADIENTBASEDALGORITHM_H_