#include "Temperature.h"
#include <math.h>
#include <iostream>
#include <fstream>

using namespace std;
Temperature::Temperature(Mesh & mesh, float m_vcast, ContinuousCaster & m_CasterOne, Steel & m_steel)
{
	mCasterOne = &m_CasterOne;
	steel = &m_steel;
	nx = mesh.nx;
	ny = mesh.ny;
	nz = mesh.nz;
	tnpts = mesh.tnpts;
	tf = mesh.tf;
	lx = mesh.lx;
	ly = mesh.ly;
	lz = mesh.lz;
	dx = mesh.dx;
	dy = mesh.dy;																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																		
	dz = mesh.dz;
	tau = mesh.tau;
	T_New = new float[nx * ny * nz];
	T_Last = new float[nx * ny * nz];
	T_Surface = new float[ny];
	meantemperature = new float[mCasterOne->coolsection];
	vcast = m_vcast;
	tstep = 0;
	disout = true;
}

Temperature::Temperature(const Temperature & m_SteelTemperature)
{
	mCasterOne = m_SteelTemperature.mCasterOne;
	steel = m_SteelTemperature.steel;
	nx = m_SteelTemperature.nx;
	ny = m_SteelTemperature.ny;
	nz = m_SteelTemperature.nz;
	tnpts = m_SteelTemperature.tnpts;
	tf = m_SteelTemperature.tf;
	lx = m_SteelTemperature.lx;
	ly = m_SteelTemperature.ly;
	lz = m_SteelTemperature.lz;
	dx = m_SteelTemperature.lx / float(m_SteelTemperature.nx - 1);
	dy = m_SteelTemperature.ly / float(m_SteelTemperature.ny - 1);
	dz = m_SteelTemperature.lz / float(m_SteelTemperature.nz - 1);
	tau = m_SteelTemperature.tf / float(m_SteelTemperature.tnpts - 1);

	T_New = new float[nx * ny * nz];
	T_Last = new float[nx * ny * nz];
	for (int j = 0; j < ny; j++)
		for (int i = 0; i < nx; i++)
			for (int k = 0; k < nz; k++)
			{
				T_Last[nx * nz * j + nz * i + k] = m_SteelTemperature.T_Last[nx * nz * j + nz * i + k];
				T_New[nx * nz * j + nz * i + k] = m_SteelTemperature.T_New[nx * nz * j + nz * i + k];
			}
	T_Surface = new float[ny];
	for (int j = 0; j < ny; j++)
		T_Surface[j] = m_SteelTemperature.T_Surface[j];

	meantemperature = new float[mCasterOne->coolsection];
	for (int i = 0; i < mCasterOne->coolsection; i++)
		meantemperature[i] = m_SteelTemperature.meantemperature[i];

	vcast = m_SteelTemperature.vcast;
	tstep = m_SteelTemperature.tstep;
	disout = m_SteelTemperature.disout;
	h = m_SteelTemperature.h;
}

Temperature::~Temperature()
{
	delete[] T_New;
	delete[] T_Last;
	delete[] T_Surface;
	delete[] meantemperature;
}

void Temperature::setvcast(float vcast, float T_Cast)
{
	this->vcast = vcast;
	this->T_Cast = T_Cast;
}
void Temperature::differencecalculation3d(float *hinit)
{
	float a, Tw = 30.0, T_Up, T_Down, T_Right, T_Left, T_Forw, T_Back, T_Middle;

	if (disout)
	{
		for (int j = 0; j < ny; j++)
		{
			this->boundarycondition3d(*mCasterOne, hinit, j);
			for (int i = 0; i < nx; i++)
				for (int m = 0; m < nz; m++)
				{
					steel->setphysicialparameters(T_Last[nx * nz * j + nz * i + m]);
					a = steel->lambda / (steel->pho * steel->ce);
					if (j == 0 && i != 0 && i != (nx - 1) && m != 0 && m != (nz - 1)) //1
					{
						T_New[nx * nz * j + nz * i + m] = T_Cast;
					}

					else if (j == 0 && i == 0 && m != 0 && m != (nz - 1)) //2
					{
						T_New[nx * nz * j + nz * i + m] = T_Cast;
					}

					else if (j == 0 && i == (nx - 1) && m != 0 && m != (nz - 1))//3
					{
						T_New[nx * nz * j + nz * i + m] = T_Cast;
					}

					else if (j == 0 && i != 0 && i != (nx - 1) && m == 0) //4
					{
						T_New[nx * nz * j + nz * i + m] = T_Cast;
					}

					else if (j == 0 && i != 0 && i != (nx - 1) && m == (nz - 1)) //5
					{
						T_New[nx * nz * j + nz * i + m] = T_Cast;
					}

					else if (j == 0 && i == 0 && m == 0)  //6
					{
						T_New[nx * nz * j + nz * i + m] = T_Cast;
					}

					else if (j == 0 && i == 0 && m == (nz - 1))  //7
					{
						T_New[nx * nz * j + nz * i + m] = T_Cast;
					}

					else if (j == 0 && i == (nx - 1) && m == 0)  //8
					{
						T_New[nx * nz * j + nz * i + m] = T_Cast;
					}

					else if (j == 0 && i == (nx - 1) && m == (nz - 1)) //9
					{
						T_New[nx * nz * j + nz * i + m] = T_Cast;
					}

					else if (j == (ny - 1) && i != 0 && i != (nx - 1) && m != 0 && m != (nz - 1)) //10
					{
						T_Middle = T_Last[nx * nz * j + nz * i + m];
						T_Up = T_Last[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_Last[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Left = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_Last[nx * nz * j + nz * i + m + 1];
						T_Back = T_Last[nx * nz * j + nz * i + m - 1];
						T_Middle = T_Last[nx * nz * j + nz * i + m];
						T_New[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j == (ny - 1) && i == 0 && m != 0 && m != (nz - 1)) //11
					{
						T_Middle = T_Last[nx * nz * j + nz * i + m];
						T_Up = T_Last[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_Last[nx * nz * j + nz * (i + 1) + m];
						T_Right = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Left = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_Last[nx * nz * j + nz * i + m + 1];
						T_Back = T_Last[nx * nz * j + nz * i + m - 1];
						T_New[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j == (ny - 1) && i == (nx - 1) && m != 0 && m != (nz - 1)) //12
					{
						T_Middle = T_Last[nx * nz * j + nz * i + m];
						T_Up = T_Last[nx * nz * j + nz * (i - 1) + m];
						T_Down = T_Last[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Left = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_Last[nx * nz * j + nz * i + m + 1];
						T_Back = T_Last[nx * nz * j + nz * i + m - 1];
						T_New[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j == (ny - 1) && i != 0 && i != (nx - 1) && m == 0)  //13
					{
						T_Middle = T_Last[nx * nz * j + nz * i + m];
						T_Up = T_Last[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_Last[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Left = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_Last[nx * nz * j + nz * i + m + 1];
						T_Back = T_Last[nx * nz * j + nz * i + m + 1];
						T_New[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j == (ny - 1) && i != 0 && i != (nx - 1) && m == (nz - 1))  //14
					{
						T_Middle = T_Last[nx * nz * j + nz * i + m];
						T_Up = T_Last[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_Last[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Left = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_Last[nx * nz * j + nz * i + m - 1];
						T_Back = T_Last[nx * nz * j + nz * i + m - 1];
						T_New[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j == (ny - 1) && i == 0 && m == 0)  //15
					{
						T_Middle = T_Last[nx * nz * j + nz * i + m];
						T_Up = T_Last[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_Last[nx * nz * j + nz * (i + 1) + m];
						T_Right = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Left = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_Last[nx * nz * j + nz * i + m + 1];
						T_Back = T_Last[nx * nz * j + nz * i + m + 1];
						T_New[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j == (ny - 1) && i == 0 && m == (nz - 1))  //16
					{
						T_Middle = T_Last[nx * nz * j + nz * i + m];
						T_Up = T_Last[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_Last[nx * nz * j + nz * (i + 1) + m];
						T_Right = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Left = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_Last[nx * nz * j + nz * i + m - 1];
						T_Back = T_Last[nx * nz * j + nz * i + m - 1];
						T_New[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j == (ny - 1) && i == (nx - 1) && m == 0)  //17
					{
						T_Middle = T_Last[nx * nz * j + nz * i + m];
						T_Up = T_Last[nx * nz * j + nz * (i - 1) + m];
						T_Down = T_Last[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Left = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_Last[nx * nz * j + nz * i + m + 1];
						T_Back = T_Last[nx * nz * j + nz * i + m + 1];
						T_New[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j == (ny - 1) && i == (nx - 1) && m == (nz - 1))  //18
					{
						T_Middle = T_Last[nx * nz * j + nz * i + m];
						T_Up = T_Last[nx * nz * j + nz * (i - 1) + m];
						T_Down = T_Last[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Left = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_Last[nx * nz * j + nz * i + m - 1];
						T_Back = T_Last[nx * nz * j + nz * i + m - 1];
						T_New[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j != 0 && j != (ny - 1) && i != 0 && i != (nx - 1) && m == 0)  //19
					{
						T_Middle = T_Last[nx * nz * j + nz * i + m];
						T_Up = T_Last[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_Last[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_Last[nx * nz * (j + 1) + nz * i + m];
						T_Left = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_Last[nx * nz * j + nz * i + m + 1];
						T_Back = T_Last[nx * nz * j + nz * i + m + 1];
						T_New[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j != 0 && j != (ny - 1) && i != 0 && i != (nx - 1) && m == (nz - 1))  //20
					{
						T_Middle = T_Last[nx * nz * j + nz * i + m];
						T_Up = T_Last[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_Last[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_Last[nx * nz * (j + 1) + nz * i + m];
						T_Left = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_Last[nx * nz * j + nz * i + m - 1] - 2 * dz * h * (T_Middle - Tw) / steel->lambda;
						T_Back = T_Last[nx * nz * j + nz * i + m - 1];
						T_New[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j != 0 && j != (ny - 1) && i == 0 && m == 0) //21
					{
						T_Middle = T_Last[nx * nz * j + nz * i + m];
						T_Up = T_Last[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_Last[nx * nz * j + nz * (i + 1) + m];
						T_Right = T_Last[nx * nz * (j + 1) + nz * i + m];
						T_Left = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_Last[nx * nz * j + nz * i + m + 1];
						T_Back = T_Last[nx * nz * j + nz * i + m + 1];
						T_New[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j != 0 && j != (ny - 1) && i == (nx - 1) && m == 0)  //22
					{
						T_Middle = T_Last[nx * nz * j + nz * i + m];
						T_Up = T_Last[nx * nz * j + nz * (i - 1) + m];
						T_Down = T_Last[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_Last[nx * nz * (j + 1) + nz * i + m];
						T_Left = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_Last[nx * nz * j + nz * i + m + 1];
						T_Back = T_Last[nx * nz * j + nz * i + m + 1];
						T_New[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j != 0 && j != (ny - 1) && i == 0 && m == (nz - 1)) //23
					{
						T_Middle = T_Last[nx * nz * j + nz * i + m];
						T_Up = T_Last[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_Last[nx * nz * j + nz * (i + 1) + m];
						T_Right = T_Last[nx * nz * (j + 1) + nz * i + m];
						T_Left = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_Last[nx * nz * j + nz * i + m - 1];
						T_Back = T_Last[nx * nz * j + nz * i + m - 1];
						T_New[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j != 0 && j != (ny - 1) && i == (nx - 1) && m == (nz - 1)) //24
					{
						T_Middle = T_Last[nx * nz * j + nz * i + m];
						T_Up = T_Last[nx * nz * j + nz * (i - 1) + m];
						T_Down = T_Last[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_Last[nx * nz * (j + 1) + nz * i + m];
						T_Left = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_Last[nx * nz * j + nz * i + m - 1];
						T_Back = T_Last[nx * nz * j + nz * i + m - 1];
						T_New[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j != 0 && j != (ny - 1) && i == 0 && m != 0 && m != (nz - 1))  //25
					{
						T_Middle = T_Last[nx * nz * j + nz * i + m];
						T_Up = T_Last[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_Last[nx * nz * j + nz * (i + 1) + m];
						T_Right = T_Last[nx * nz * (j + 1) + nz * i + m];
						T_Left = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_Last[nx * nz * j + nz * i + m + 1];
						T_Back = T_Last[nx * nz * j + nz * i + m - 1];
						T_New[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j != 0 && j != (ny - 1) && i == (nx - 1) && m != 0 && m != (nz - 1)) //26
					{
						T_Middle = T_Last[nx * nz * j + nz * i + m];
						T_Up = T_Last[nx * nz * j + nz * (i - 1) + m] - 2 * dx * h * (T_Middle - Tw) / steel->lambda;
						T_Down = T_Last[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_Last[nx * nz * (j + 1) + nz * i + m];
						T_Left = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_Last[nx * nz * j + nz * i + m + 1];
						T_Back = T_Last[nx * nz * j + nz * i + m - 1];
						T_New[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else  //27
					{
						T_Middle = T_Last[nx * nz * j + nz * i + m];
						T_Up = T_Last[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_Last[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_Last[nx * nz * (j + 1) + nz * i + m];
						T_Left = T_Last[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_Last[nx * nz * j + nz * i + m + 1];
						T_Back = T_Last[nx * nz * j + nz * i + m - 1];
						T_New[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}
				}
		}
		for (int k = 0; k < ny; k++)
			//T_Surface[k] = 1558.0f;
			T_Surface[k] = T_New[nx * nz * k + nz * int((nx - 1) / 2) + nz - 1];
	}
	else
	{
		for (int j = 0; j < ny; j++)
		{
			this->boundarycondition3d(*mCasterOne, hinit, j);
			for (int i = 0; i < nx; i++)
				for (int m = 0; m < nz; m++)
				{
					steel->setphysicialparameters(T_Last[nx * nz * j + nz * i + m]);
					a = steel->lambda / (steel->pho * steel->ce);
					if (j == 0 && i != 0 && i != (nx - 1) && m != 0 && m != (nz - 1)) //1
					{
						T_Last[nx * nz * j + nz * i + m] = T_Cast;
					}

					else if (j == 0 && i == 0 && m != 0 && m != (nz - 1)) //2
					{
						T_Last[nx * nz * j + nz * i + m] = T_Cast;
					}

					else if (j == 0 && i == (nx - 1) && m != 0 && m != (nz - 1))//3
					{
						T_Last[nx * nz * j + nz * i + m] = T_Cast;
					}

					else if (j == 0 && i != 0 && i != (nx - 1) && m == 0) //4
					{
						T_Last[nx * nz * j + nz * i + m] = T_Cast;
					}

					else if (j == 0 && i != 0 && i != (nx - 1) && m == (nz - 1)) //5
					{
						T_Last[nx * nz * j + nz * i + m] = T_Cast;
					}

					else if (j == 0 && i == 0 && m == 0)  //6
					{
						T_Last[nx * nz * j + nz * i + m] = T_Cast;
					}

					else if (j == 0 && i == 0 && m == (nz - 1))  //7
					{
						T_Last[nx * nz * j + nz * i + m] = T_Cast;
					}

					else if (j == 0 && i == (nx - 1) && m == 0)  //8
					{
						T_Last[nx * nz * j + nz * i + m] = T_Cast;
					}

					else if (j == 0 && i == (nx - 1) && m == (nz - 1)) //9
					{
						T_Last[nx * nz * j + nz * i + m] = T_Cast;
					}

					else if (j == (ny - 1) && i != 0 && i != (nx - 1) && m != 0 && m != (nz - 1)) //10
					{
						T_Middle = T_New[nx * nz * j + nz * i + m];
						T_Up = T_New[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_New[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Left = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_New[nx * nz * j + nz * i + m + 1];
						T_Back = T_New[nx * nz * j + nz * i + m - 1];
						T_Middle = T_New[nx * nz * j + nz * i + m];
						T_Last[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j == (ny - 1) && i == 0 && m != 0 && m != (nz - 1)) //11
					{
						T_Middle = T_New[nx * nz * j + nz * i + m];
						T_Up = T_New[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_New[nx * nz * j + nz * (i + 1) + m];
						T_Right = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Left = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_New[nx * nz * j + nz * i + m + 1];
						T_Back = T_New[nx * nz * j + nz * i + m - 1];
						T_Last[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j == (ny - 1) && i == (nx - 1) && m != 0 && m != (nz - 1)) //12
					{
						T_Middle = T_New[nx * nz * j + nz * i + m];
						T_Up = T_New[nx * nz * j + nz * (i - 1) + m];
						T_Down = T_New[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Left = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_New[nx * nz * j + nz * i + m + 1];
						T_Back = T_New[nx * nz * j + nz * i + m - 1];
						T_Last[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j == (ny - 1) && i != 0 && i != (nx - 1) && m == 0)  //13
					{
						T_Middle = T_New[nx * nz * j + nz * i + m];
						T_Up = T_New[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_New[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Left = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_New[nx * nz * j + nz * i + m + 1];
						T_Back = T_New[nx * nz * j + nz * i + m + 1];
						T_Last[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j == (ny - 1) && i != 0 && i != (nx - 1) && m == (nz - 1))  //14
					{
						T_Middle = T_New[nx * nz * j + nz * i + m];
						T_Up = T_New[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_New[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Left = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_New[nx * nz * j + nz * i + m - 1];
						T_Back = T_New[nx * nz * j + nz * i + m - 1];
						T_Last[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j == (ny - 1) && i == 0 && m == 0)  //15
					{
						T_Middle = T_New[nx * nz * j + nz * i + m];
						T_Up = T_New[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_New[nx * nz * j + nz * (i + 1) + m];
						T_Right = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Left = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_New[nx * nz * j + nz * i + m + 1];
						T_Back = T_New[nx * nz * j + nz * i + m + 1];
						T_Last[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j == (ny - 1) && i == 0 && m == (nz - 1))  //16
					{
						T_Middle = T_New[nx * nz * j + nz * i + m];
						T_Up = T_New[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_New[nx * nz * j + nz * (i + 1) + m];
						T_Right = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Left = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_New[nx * nz * j + nz * i + m - 1];
						T_Back = T_New[nx * nz * j + nz * i + m - 1];
						T_Last[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j == (ny - 1) && i == (nx - 1) && m == 0)  //17
					{
						T_Middle = T_New[nx * nz * j + nz * i + m];
						T_Up = T_New[nx * nz * j + nz * (i - 1) + m];
						T_Down = T_New[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Left = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_New[nx * nz * j + nz * i + m + 1];
						T_Back = T_New[nx * nz * j + nz * i + m + 1];
						T_Last[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j == (ny - 1) && i == (nx - 1) && m == (nz - 1))  //18
					{
						T_Middle = T_New[nx * nz * j + nz * i + m];
						T_Up = T_New[nx * nz * j + nz * (i - 1) + m];
						T_Down = T_New[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Left = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_New[nx * nz * j + nz * i + m - 1];
						T_Back = T_New[nx * nz * j + nz * i + m - 1];
						T_Last[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j != 0 && j != (ny - 1) && i != 0 && i != (nx - 1) && m == 0)  //19
					{
						T_Middle = T_New[nx * nz * j + nz * i + m];
						T_Up = T_New[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_New[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_New[nx * nz * (j + 1) + nz * i + m];
						T_Left = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_New[nx * nz * j + nz * i + m + 1];
						T_Back = T_New[nx * nz * j + nz * i + m + 1];
						T_Last[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j != 0 && j != (ny - 1) && i != 0 && i != (nx - 1) && m == (nz - 1))  //20
					{
						T_Middle = T_New[nx * nz * j + nz * i + m];
						T_Up = T_New[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_New[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_New[nx * nz * (j + 1) + nz * i + m];
						T_Left = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_New[nx * nz * j + nz * i + m - 1] - 2 * dz * h * (T_Middle - Tw) / steel->lambda;
						T_Back = T_New[nx * nz * j + nz * i + m - 1];
						T_Last[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j != 0 && j != (ny - 1) && i == 0 && m == 0) //21
					{
						T_Middle = T_New[nx * nz * j + nz * i + m];
						T_Up = T_New[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_New[nx * nz * j + nz * (i + 1) + m];
						T_Right = T_New[nx * nz * (j + 1) + nz * i + m];
						T_Left = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_New[nx * nz * j + nz * i + m + 1];
						T_Back = T_New[nx * nz * j + nz * i + m + 1];
						T_Last[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j != 0 && j != (ny - 1) && i == (nx - 1) && m == 0)  //22
					{
						T_Middle = T_New[nx * nz * j + nz * i + m];
						T_Up = T_New[nx * nz * j + nz * (i - 1) + m];
						T_Down = T_New[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_New[nx * nz * (j + 1) + nz * i + m];
						T_Left = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_New[nx * nz * j + nz * i + m + 1];
						T_Back = T_New[nx * nz * j + nz * i + m + 1];
						T_Last[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j != 0 && j != (ny - 1) && i == 0 && m == (nz - 1)) //23
					{
						T_Middle = T_New[nx * nz * j + nz * i + m];
						T_Up = T_New[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_New[nx * nz * j + nz * (i + 1) + m];
						T_Right = T_New[nx * nz * (j + 1) + nz * i + m];
						T_Left = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_New[nx * nz * j + nz * i + m - 1];
						T_Back = T_New[nx * nz * j + nz * i + m - 1];
						T_Last[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j != 0 && j != (ny - 1) && i == (nx - 1) && m == (nz - 1)) //24
					{
						T_Middle = T_New[nx * nz * j + nz * i + m];
						T_Up = T_New[nx * nz * j + nz * (i - 1) + m];
						T_Down = T_New[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_New[nx * nz * (j + 1) + nz * i + m];
						T_Left = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_New[nx * nz * j + nz * i + m - 1];
						T_Back = T_New[nx * nz * j + nz * i + m - 1];
						T_Last[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j != 0 && j != (ny - 1) && i == 0 && m != 0 && m != (nz - 1))  //25
					{
						T_Middle = T_New[nx * nz * j + nz * i + m];
						T_Up = T_New[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_New[nx * nz * j + nz * (i + 1) + m];
						T_Right = T_New[nx * nz * (j + 1) + nz * i + m];
						T_Left = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_New[nx * nz * j + nz * i + m + 1];
						T_Back = T_New[nx * nz * j + nz * i + m - 1];
						T_Last[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else if (j != 0 && j != (ny - 1) && i == (nx - 1) && m != 0 && m != (nz - 1)) //26
					{
						T_Middle = T_New[nx * nz * j + nz * i + m];
						T_Up = T_New[nx * nz * j + nz * (i - 1) + m] - 2 * dx * h * (T_Middle - Tw) / steel->lambda;
						T_Down = T_New[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_New[nx * nz * (j + 1) + nz * i + m];
						T_Left = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_New[nx * nz * j + nz * i + m + 1];
						T_Back = T_New[nx * nz * j + nz * i + m - 1];
						T_Last[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;
					}

					else  //27
					{
						T_Middle = T_New[nx * nz * j + nz * i + m];
						T_Up = T_New[nx * nz * j + nz * (i + 1) + m];
						T_Down = T_New[nx * nz * j + nz * (i - 1) + m];
						T_Right = T_New[nx * nz * (j + 1) + nz * i + m];
						T_Left = T_New[nx * nz * (j - 1) + nz * i + m];
						T_Forw = T_New[nx * nz * j + nz * i + m + 1];
						T_Back = T_New[nx * nz * j + nz * i + m - 1];
						T_Last[nx * nz * j + nz * i + m] = (a * tau / (dx * dx)) * T_Up + a * (tau / (dx * dx)) * T_Down + ((1 - 2 * a * tau / (dx * dx) - 2 * a * tau / (dy * dy) - 2 * a * tau / (dz * dz) + tau * vcast / dy)) * T_Middle
							+ (a * tau / (dy * dy)) * T_Right + (a * tau / (dy * dy) - tau * vcast / dy) * T_Left + (a * tau / (dz * dz)) * T_Forw + (a * tau / (dz * dz)) * T_Back;

					}
				}
		}
		for (int k = 0; k < ny; k++)
			//T_Surface[k] = 1558.0f;
			T_Surface[k] = T_Last[nx * nz * k + nz * int((nx - 1) / 2) + nz - 1];
	}
		disout = !disout;
		tstep++;
}

void Temperature::boundarycondition3d(ContinuousCaster & CasterOne, float *hinit, int j)
{
	float yposition = dy * j;
	for (int i = 0; i < CasterOne.section; i++)
		if (yposition >= *(CasterOne.sectionlength + i) && yposition <= *(CasterOne.sectionlength + i + 1))
			h = *(hinit + i);
}

void Temperature::initcondition3d(float T_Cast)
{
	tstep = 0;
	for (int j = 0; j < ny; j++)
		for (int i = 0; i < nx; i++)
			for (int k = 0; k < nz; k++)
			{
				T_Last[nx * nz * j + nz * i + k] = T_Cast;
				T_New[nx * nz * j + nz * i + k] = T_Cast;
			}
	disout = true;
}

void Temperature::initcondition3d(float *T_Cast)
{
	tstep = 0;
	for (int j = 0; j < ny; j++)
		for (int i = 0; i < nx; i++)
			for (int k = 0; k < nz; k++)
			{
				T_Last[nx * nz * j + nz * i + k] = T_Cast[nx * nz * j + nz * i + k];
				T_New[nx * nz * j + nz * i + k] = T_Cast[nx * nz * j + nz * i + k];
			}
	disout = true;
}


void Temperature::computetemperature3d(float *measuredpoistion, int measurednumb)
{
	computetemperature = new float[measurednumb];
	for (int i = 0; i < measurednumb; i++)
		for (int j = 0; j < ny; j++)
			if (fabs(j * dy - *(measuredpoistion + i)) <= dy)
				computetemperature[i] = T_Surface[j];
}

void Temperature::computemeantemperature3d()
{
	float y;
	int count = 0;
	for (int i = 0; i < mCasterOne->coolsection; i++)
	{
		meantemperature[i] = 0.0;
		for (int j = 0; j < ny; j++)
		{
			y = j * dy;
			if (y > *((mCasterOne->sectionlength) + i + mCasterOne->moldsection) && y <= *((mCasterOne->sectionlength) + i + 1 + +mCasterOne->moldsection))
			{
				meantemperature[i] += T_Surface[j];
				count++;
			}
		}
		meantemperature[i] = meantemperature[i] / count;
		count = 0;
	}
}

void Temperature::print(int measurednumb)
{
	if (tstep == 0)
	{
		cout << "lx = " << lx << ", " << "nx = " << nx << ", ";
		cout << "ly = " << ly << ", " << "ny = " << ny << ", ";
		cout << "lz = " << lz << ", " << "nz = " << nz << ", ";
		cout << "casting speed = " << vcast << ", ";
		cout << "dx = " << dx << ", ";
		cout << "dy = " << dy << ", ";
		cout << "dz = " << dz << ", ";
		cout << "time step = " << tau << ", ";
	}
	else
	{
		cout << "computetemperature = " << endl;
		for (int i = 0; i < measurednumb; i++)
			cout << computetemperature[i] << ", ";
		cout << endl;
	}
}

void Temperature::print()
{
	if (tstep == 0)
	{
		cout << "lx = " << lx << ", " << "nx = " << nx << ", ";
		cout << "ly = " << ly << ", " << "ny = " << ny << ", ";
		cout << "lz = " << lz << ", " << "nz = " << nz << ", ";
		cout << "casting speed = " << vcast << ", " << endl;
		cout << "dx = " << dx << ", ";
		cout << "dy = " << dy << ", ";
		cout << "dz = " << dz << ", ";
		cout << "time step = " << tau << ", " << endl;
		//cout << "tstep = " << tstep << endl;
		//cout << "meantemperature = " << endl;
		//for (int i = 0; i < mCasterOne->coolsection; i++)
		//	cout << meantemperature[i] << ", ";
		//cout << endl;
		//ofstream outputfile;
		//outputfile.open("D:\\Project1\\3DTemperature.csv", ios::app);
		//for (int i = 0; i < mCasterOne->coolsection; i++)
		//	outputfile << meantemperature[i] << "  ";
		//outputfile << endl;
		//outputfile.close();
	}
	else
	{
		cout << "tstep = " << tstep << endl;
		cout << "meantemperature = " << endl;
		for (int i = 0; i < mCasterOne->coolsection; i++)
			cout << meantemperature[i] << ", ";
		cout << endl;
		ofstream outputfile;
		outputfile.open("C:\\Users\\Administrator\\Desktop\\����Ч��\\3dWithoutCUDA\\WithoutCUDA_Conjugategradient_3DTemperature.csv", ios::app);
		for (int i = 0; i < mCasterOne->coolsection; i++)
			outputfile << meantemperature[i] << "  ";
		outputfile << endl;
		outputfile.close();
	}
}

void Temperature::outputdata()
{
	ofstream outputfile;
	outputfile.open("C:\\Users\\Administrator\\Desktop\\����Ч��\\3dWithoutCUDA\\3DTemperaturefield.csv", ios::app);
	for (int i = 0; i < ny; i++)
	{
		for (int j = 0; j < nx; j++)
		{
			for (int k = 0; k < nz; k++)
				outputfile << T_New[i * nx * nz + j * nz + k] << " ";
			outputfile << endl;
		}
		outputfile << endl;
	}
	outputfile.close();

}

void Temperature::operator=(const Temperature & m_SteelTemperature)
{
	mCasterOne = m_SteelTemperature.mCasterOne;
	steel = m_SteelTemperature.steel;
	nx = m_SteelTemperature.nx;
	ny = m_SteelTemperature.ny;
	nz = m_SteelTemperature.nz;
	tnpts = m_SteelTemperature.tnpts;
	tf = m_SteelTemperature.tf;
	lx = m_SteelTemperature.lx;
	ly = m_SteelTemperature.ly;
	lz = m_SteelTemperature.lz;
	dx = m_SteelTemperature.lx / float(m_SteelTemperature.nx - 1);
	dy = m_SteelTemperature.ly / float(m_SteelTemperature.ny - 1);
	dz = m_SteelTemperature.lz / float(m_SteelTemperature.nz - 1);
	tau = m_SteelTemperature.tf / float(m_SteelTemperature.tnpts - 1);
	vcast = m_SteelTemperature.vcast;
	T_Cast = m_SteelTemperature.T_Cast;
	delete[] T_New;
	delete[] T_Last;
	delete[] T_Surface;
	delete[] meantemperature;

	T_New = new float[nx * ny * nz];
	T_Last = new float[nx * ny * nz];
	for (int j = 0; j < ny; j++)
		for (int i = 0; i < nx; i++)
			for (int k = 0; k < nz; k++)
			{
				T_Last[nx * nz * j + nz * i + k] = m_SteelTemperature.T_Last[nx * nz * j + nz * i + k];
				T_New[nx * nz * j + nz * i + k] = m_SteelTemperature.T_New[nx * nz * j + nz * i + k];
			}
	T_Surface = new float[ny];
	for (int j = 0; j < ny; j++)
		T_Surface[j] = m_SteelTemperature.T_Surface[j];

	meantemperature = new float[mCasterOne->coolsection];
	for (int i = 0; i < mCasterOne->coolsection; i++)
		meantemperature[i] = m_SteelTemperature.meantemperature[i];

	vcast = m_SteelTemperature.vcast;
	tstep = m_SteelTemperature.tstep;
	disout = m_SteelTemperature.disout;
}