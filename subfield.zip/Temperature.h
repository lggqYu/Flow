#pragma once
#ifndef __TEMPERATURE_H__
#define __TEMPERATURE_H__
#include "ContinuousCaster.h"
#include "Steel.h"
#include "Mesh.h"
class Temperature
{
    protected:
	    float vcast, T_Cast;
	    float h;
	    float* T_New;
	    float* T_Last;
	    float* T_Surface;
	    bool disout;
	    int nx, ny, nz, tnpts;
	    float dx, dy, dz, tau, tf, lx, ly, lz;
	    ContinuousCaster* mCasterOne;
	    Steel* steel;
    public:
	    int tstep;
	    float* meantemperature;
	    float* computetemperature;
	    Temperature(Mesh &, float, ContinuousCaster &, Steel &);
	    Temperature(const Temperature &);
	    ~Temperature();
	    void differencecalculation3d(float*);
	    void boundarycondition3d(ContinuousCaster &, float*, int);
	    void initcondition3d(float);
	    void initcondition3d(float*);
	    void print(int);
		void print();
		void outputdata();
	    void computetemperature3d(float *, int);
	    void computemeantemperature3d();
	    void setvcast(float, float);
	    void operator=(const Temperature&);
	    friend class Gradientbasedalgorithm;
}; 
#endif // !__TEMPERATURE_H__
