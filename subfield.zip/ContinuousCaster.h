#pragma once
#ifndef __CONTINUOUSCASTER_H__
#define __CONTINUOUSCASTER_H__
class ContinuousCaster
{
    public:
	    int section, coolsection, moldsection;
	    float *sectionlength;
	    ContinuousCaster(int, int, int, float*);
	    ~ContinuousCaster();
	    void print();
};
#endif // !__CONTINUOUSCASTER_H__