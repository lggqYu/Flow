#include <iostream>
#include <cmath>
#include <iomanip>

constexpr double EARTH_RADIUS = 6371.0; // 地球平均半径（公里）

// 角度转弧度
double degreesToRadians(double degrees) {
    return degrees * M_PI / 180.0;
}

// 使用Haversine公式计算两点间距离
double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
    double lat1Rad = degreesToRadians(lat1);
    double lon1Rad = degreesToRadians(lon1);
    double lat2Rad = degreesToRadians(lat2);
    double lon2Rad = degreesToRadians(lon2);
    
    double deltaLat = lat2Rad - lat1Rad;
    double deltaLon = lon2Rad - lon1Rad;
    
    double a = pow(sin(deltaLat / 2), 2) + 
               cos(lat1Rad) * cos(lat2Rad) * 
               pow(sin(deltaLon / 2), 2);
    
    double c = 2 * atan2(sqrt(a), sqrt(1 - a));
    
    return EARTH_RADIUS * c; // 返回距离（公里）
}

// 计算俯仰角（单位：度）
double calculatePitchAngle(double startAltitude, double endAltitude, double horizontalDistance) {
    // 计算高度差（米）
    double deltaH = endAltitude - startAltitude;
    
    // 计算俯仰角（弧度）
    double pitchRad = atan2(deltaH, horizontalDistance * 1000);
    
    // 转换为角度
    return pitchRad * 180.0 / M_PI;
}

int main() {
    // 定义两个点的坐标
    double pointA_lat = 35.641;   // 起始点纬度
    double pointA_lon = 111.411;  // 起始点经度
    double pointA_alt = 500;      // 起始点高度（米）
    
    double pointB_lat = 35.741;   // 终止点纬度
    double pointB_lon = 111.417;  // 终止点经度
    double pointB_alt = 1000;     // 终止点高度（米）
    
    // 计算水平距离
    double distanceKm = calculateDistance(
        pointA_lat, pointA_lon,
        pointB_lat, pointB_lon
    );
    
    // 计算俯仰角
    double pitchAngle = calculatePitchAngle(
        pointA_alt, pointB_alt, distanceKm
    );
    
    // 计算实际斜边距离
    double deltaH = pointB_alt - pointA_alt;
    double actualDistance = sqrt(pow(distanceKm * 1000, 2) + pow(deltaH, 2));
    
    // 输出结果
    std::cout << "飞行路径分析\n";
    std::cout << "========================================\n";
    std::cout << "起始点: (" << pointA_lat << "°, " << pointA_lon << "°) 高度: " << pointA_alt << " 米\n";
    std::cout << "终止点: (" << pointB_lat << "°, " << pointB_lon << "°) 高度: " << pointB_alt << " 米\n";
    std::cout << "----------------------------------------\n";
    std::cout << std::fixed << std::setprecision(3);
    std::cout << "水平距离: " << distanceKm << " 公里 (" << distanceKm * 1000 << " 米)\n";
    std::cout << "高度差: " << deltaH << " 米\n";
    std::cout << "实际飞行距离: " << actualDistance / 1000 << " 公里 (" << actualDistance << " 米)\n";
    std::cout << "----------------------------------------\n";
    std::cout << "飞机俯仰角: " << std::setprecision(2) << pitchAngle << "°\n";
    
    // 飞行状态判断
    std::cout << "----------------------------------------\n";
    std::cout << "飞行状态: ";
    if (pitchAngle > 5.0) {
        std::cout << "陡峭爬升";
    } else if (pitchAngle > 2.0) {
        std::cout << "中等爬升";
    } else if (pitchAngle > 0.5) {
        std::cout << "平缓爬升";
    } else if (pitchAngle > -0.5) {
        std::cout << "平飞";
    } else if (pitchAngle > -2.0) {
        std::cout << "平缓下降";
    } else if (pitchAngle > -5.0) {
        std::cout << "中等下降";
    } else {
        std::cout << "陡峭下降";
    }
    std::cout << "\n========================================\n";
    
    return 0;
}