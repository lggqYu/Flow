#include <iostream>
#include <cmath>
#include <chrono>

class PitchController {
private:
    // PID控制参数
    double Kp;      // 比例增益
    double Ki;      // 积分增益
    double Kd;      // 微分增益
    
    // 控制器状态
    double prev_error;   // 上一次误差
    double integral;     // 积分项累加值
    double prev_time;    // 上一次更新时间
    
    // 升降舵限制
    const double ELEVATOR_MAX = 25.0;  // 最大偏转角度(度)
    const double ELEVATOR_MIN = -25.0; // 最小偏转角度(度)
    
public:
    PitchController(double p, double i, double d)
        : Kp(p), Ki(i), Kd(d), prev_error(0), integral(0), prev_time(0) {}
    
    // 重置控制器状态
    void reset() {
        prev_error = 0;
        integral = 0;
        prev_time = 0;
    }
    
    // 计算升降舵输入量
    double computeElevatorInput(double current_pitch, double target_pitch) {
        // 获取当前时间
        auto now = std::chrono::steady_clock::now();
        double current_time = std::chrono::duration<double>(now.time_since_epoch()).count();
        
        // 如果是第一次调用，初始化时间
        if (prev_time == 0) {
            prev_time = current_time;
            prev_error = target_pitch - current_pitch;
            return 0;
        }
        
        // 计算时间间隔
        double dt = current_time - prev_time;
        if (dt <= 0) dt = 0.01; // 避免除零错误
        
        // 计算当前误差
        double error = target_pitch - current_pitch;
        
        // 计算误差的积分项（带抗饱和处理）
        integral += error * dt;
        
        // 计算误差的微分项
        double derivative = (error - prev_error) / dt;
        
        // PID控制律
        double output = Kp * error + Ki * integral + Kd * derivative;
        
        // 应用输出限制
        output = std::max(std::min(output, ELEVATOR_MAX), ELEVATOR_MIN);
        
        // 更新状态
        prev_error = error;
        prev_time = current_time;
        
        return output;
    }
};

int main() {
    // 创建俯仰控制器 (参数需要根据具体飞机调整)
    PitchController controller(1.2, 0.05, 0.8);
    
    // 模拟飞行状态
    double current_pitch = 2.0;   // 当前俯仰角(度)
    double target_pitch = 5.0;    // 目标俯仰角(度)
    
    // 模拟时间步进
    for (int i = 0; i < 20; i++) {
        // 计算升降舵输入
        double elevator = controller.computeElevatorInput(current_pitch, target_pitch);
        
        // 模拟飞机响应（简化模型）
        // 俯仰角变化率与升降舵输入成正比
        double pitch_rate = elevator * 0.3; // 比例系数取决于飞机特性
        
        // 更新俯仰角
        current_pitch += pitch_rate * 0.1; // 0.1秒时间步长
        
        // 输出结果
        std::cout << "时间: " << i*0.1 << "秒, ";
        std::cout << "当前俯仰角: " << current_pitch << "°, ";
        std::cout << "升降舵: " << elevator << "°, ";
        std::cout << "目标: " << target_pitch << "°" << std::endl;
        
        // 每5秒改变目标（模拟）
        if (i == 10) {
            target_pitch = 0.0;
            std::cout << "\n==== 目标改变为平飞 ====\n";
        }
    }
    
    return 0;
}