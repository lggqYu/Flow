#include "XmlOperation.h"

void generateSystemInfoXml(const QString& filePath, QString SystemPath)
{
    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        return;
    }

    QXmlStreamWriter xmlWriter(&file);
    xmlWriter.setAutoFormatting(true);  // 设置自动格式化，使输出更易读
    xmlWriter.setCodec("UTF-8");        // 设置编码为UTF-8

    // 写入XML声明
    xmlWriter.writeStartDocument("1.0", true);

    // 写入Workflow根元素及其属性
    xmlWriter.writeStartElement("Workflow");
    xmlWriter.writeAttribute("version", "1.0");
    xmlWriter.writeAttribute("name", "SystemInfo");

    // 写入System元素及其Path属性
    xmlWriter.writeEmptyElement("System");
    xmlWriter.writeAttribute("Path", SystemPath);

    // 结束Workflow元素
    xmlWriter.writeEndElement();

    // 结束文档
    xmlWriter.writeEndDocument();

    file.close();
}

void readSystemInfoXml(const QString& filePath, QString& SystemPath)
{
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return;
    }

    QXmlStreamReader xmlReader(&file);
    while (!xmlReader.atEnd() && !xmlReader.hasError()) {
        xmlReader.readNext();

        if (xmlReader.isStartElement()) {
/*            if (xmlReader.name() == "Workflow") {
                qDebug() << "Workflow version:" << xmlReader.attributes().value("version").toString();
                qDebug() << "Workflow name:" << xmlReader.attributes().value("name").toString();
            }
            else */if (xmlReader.name() == "System") {
                SystemPath = xmlReader.attributes().value("Path").toString();
            }
        }
    }

    if (xmlReader.hasError()) {
        file.close();
        return;
    }
    file.close();
}

void generatePathXmlFile(const QString& filePath) {
    QString path = filePath + "/ConfigPth.xml";
    QFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        return;
    }

    QXmlStreamWriter xmlWriter(&file);
    xmlWriter.setAutoFormatting(true);  // 设置自动格式化，使输出更易读
    xmlWriter.setCodec("UTF-8");        // 设置编码为UTF-8

    // 写入XML声明
    xmlWriter.writeStartDocument("1.0", true);

    // 写入Workflow根元素及其属性
    xmlWriter.writeStartElement("Workflow");
    xmlWriter.writeAttribute("version", "1.0");
    xmlWriter.writeAttribute("name", "projectInfo");

    // 写入元素及其Path属性
    xmlWriter.writeEmptyElement("Config");
    xmlWriter.writeAttribute("Path", filePath + "/配置文件");

    xmlWriter.writeEmptyElement("Project");
    xmlWriter.writeAttribute("Path", filePath + "/工程文件");

    xmlWriter.writeEmptyElement("Image");
    xmlWriter.writeAttribute("Path", filePath + "/图片");

    // 结束Workflow元素
    xmlWriter.writeEndElement();

    // 结束文档
    xmlWriter.writeEndDocument();

    file.close();
}

void readConfigInfoXml(const QString& filePath, QString& ConfigPath, QString& projectPath, QString& imagetPath)
{
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return;
    }

    QXmlStreamReader xmlReader(&file);
    while (!xmlReader.atEnd() && !xmlReader.hasError()) {
        xmlReader.readNext();

        if (xmlReader.isStartElement()) 
        {
            if (xmlReader.name() == "Config")
            {
                ConfigPath = xmlReader.attributes().value("Path").toString();
            }
            else if (xmlReader.name() == "Project")
            {
                projectPath = xmlReader.attributes().value("Path").toString();
            }
            else if (xmlReader.name() == "Image")
            {
                imagetPath = xmlReader.attributes().value("Path").toString();
            }
        }
    }

    if (xmlReader.hasError()) {
        file.close();
        return;
    }
    file.close();
}
