#ifndef XMLOPERATION_H
#define XMLOPERATION_H

#include <QCoreApplication>
#include <QFile>
#include <QXmlStreamWriter>

void generateSystemInfoXml(const QString& filePath, QString SystemPath);     //生成系统路径xml
void readSystemInfoXml(const QString& filePath, QString& SystemPath);        //读取系统路径xml
void generatePathXmlFile(const QString& filePath);                           //生成工程路径xml
void readConfigInfoXml(const QString& filePath, QString& ConfigPath, QString& projectPath, QString& imagetPath);//读取工程路径xml
#endif // XMLOPERATION_H
