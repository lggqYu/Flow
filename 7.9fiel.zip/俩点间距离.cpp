#include <iostream>
#include <cmath>

// 地球平均半径（单位：公里）
constexpr double EARTH_RADIUS = 6371.0;

// 将角度转换为弧度
double degreesToRadians(double degrees) {
    return degrees * M_PI / 180.0;
}

// 使用 Haversine 公式计算两点间距离
double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
    // 将经纬度转换为弧度
    double lat1Rad = degreesToRadians(lat1);
    double lon1Rad = degreesToRadians(lon1);
    double lat2Rad = degreesToRadians(lat2);
    double lon2Rad = degreesToRadians(lon2);
    
    // 计算纬度和经度的差值
    double deltaLat = lat2Rad - lat1Rad;
    double deltaLon = lon2Rad - lon1Rad;
    
    // Haversine 公式
    double a = pow(sin(deltaLat / 2), 2) + 
               cos(lat1Rad) * cos(lat2Rad) * 
               pow(sin(deltaLon / 2), 2);
    
    double c = 2 * atan2(sqrt(a), sqrt(1 - a));
    
    // 计算距离
    return EARTH_RADIUS * c;
}

int main() {
    // 定义两个点的坐标（纬度, 经度）
    double pointA_lat = 35.641;
    double pointA_lon = 111.411;
    double pointB_lat = 35.741;
    double pointB_lon = 111.417;
    
    // 计算距离
    double distance = calculateDistance(
        pointA_lat, pointA_lon,
        pointB_lat, pointB_lon
    );
    
    // 输出结果
    std::cout << "点 A: (" << pointA_lat << "°, " << pointA_lon << "°)" << std::endl;
    std::cout << "点 B: (" << pointB_lat << "°, " << pointB_lon << "°)" << std::endl;
    std::cout.precision(5);
    std::cout << "两点间距离: " << distance << " 公里" << std::endl;
    std::cout << "约 " << distance * 1000 << " 米" << std::endl;
    
    return 0;
}