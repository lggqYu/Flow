#ifndef PARALLELOGRAMBUTTON_H
#define PARALLELOGRAMBUTTON_H
#include <QPushButton>
#include <QPainter>
#include <QApplication>
#include <cmath>
#include <iostream>

class ParallelogramButton : public QPushButton
{
public:
    ParallelogramButton(const QString &text, QWidget *parent = nullptr)
        : QPushButton(text, parent), skewAngle(50),m_height(40) {
        setFixedHeight(m_height);
    }

    void setSkewAngle(int angle) {
        skewAngle = angle;
        update();
    }

protected:
    void paintEvent(QPaintEvent *event) override {
        Q_UNUSED(event);

        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing);

        // 创建平行四边形路径
        QPainterPath path;
        int offset = height() * tan(skewAngle * 3.1415 / 180.0);
        path.moveTo(offset, 0);
        path.lineTo(width(), 0);
        path.lineTo(width() - offset, height());
        path.lineTo(0, height());
        path.closeSubpath();

        // 绘制背景
        painter.setPen(Qt::NoPen);
        QColor bgColor = isDown() ? QColor(62, 142, 65) :
                          underMouse() ? QColor(69, 160, 73) : QColor(76, 175, 80);
        painter.fillPath(path, bgColor);

        // 绘制文本
        painter.save();
        QTransform transform;
        transform.translate(offset/2, 0);
        painter.setTransform(transform);
        painter.setPen(Qt::white);
        painter.drawText(rect(), Qt::AlignCenter, text());
        painter.restore();
    }

private:
    int skewAngle;
    int m_height;
};
#endif // PARALLELOGRAMBUTTON_H
